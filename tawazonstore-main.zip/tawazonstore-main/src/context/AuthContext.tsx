import React, { createContext, useContext, useReducer, ReactNode, useEffect } from 'react';

export interface User {
  id: string;
  email: string;
  name: string;
  country: string;
  favorites: number[];
}

interface AuthState {
  user: User | null;
  isLoading: boolean;
  isAuthenticated: boolean;
}

type AuthAction =
  | { type: 'LOGIN_START' }
  | { type: 'LOGIN_SUCCESS'; payload: User }
  | { type: 'LOGIN_FAILURE' }
  | { type: 'LOGOUT' }
  | { type: 'UPDATE_USER'; payload: Partial<User> };

const AuthContext = createContext<{
  state: AuthState;
  dispatch: React.Dispatch<AuthAction>;
  login: (email: string, password: string) => Promise<boolean>;
  signup: (email: string, password: string, name: string, country: string) => Promise<boolean>;
  logout: () => void;
  addToFavorites: (productId: number) => void;
  removeFromFavorites: (productId: number) => void;
} | null>(null);

const authReducer = (state: AuthState, action: AuthAction): AuthState => {
  switch (action.type) {
    case 'LOGIN_START':
      return { ...state, isLoading: true };
    case 'LOGIN_SUCCESS':
      return { 
        user: action.payload, 
        isLoading: false, 
        isAuthenticated: true 
      };
    case 'LOGIN_FAILURE':
      return { 
        user: null, 
        isLoading: false, 
        isAuthenticated: false 
      };
    case 'LOGOUT':
      return { 
        user: null, 
        isLoading: false, 
        isAuthenticated: false 
      };
    case 'UPDATE_USER':
      return {
        ...state,
        user: state.user ? { ...state.user, ...action.payload } : null
      };
    default:
      return state;
  }
};

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(authReducer, {
    user: null,
    isLoading: false,
    isAuthenticated: false
  });

  useEffect(() => {
    // Check for stored user session
    const storedUser = localStorage.getItem('tawazon_user');
    if (storedUser) {
      try {
        const user = JSON.parse(storedUser);
        dispatch({ type: 'LOGIN_SUCCESS', payload: user });
      } catch (error) {
        localStorage.removeItem('tawazon_user');
      }
    }
  }, []);

  const login = async (email: string, password: string): Promise<boolean> => {
    dispatch({ type: 'LOGIN_START' });
    
    try {
      // Mock authentication - in real app, this would be API call
      const mockUser: User = {
        id: '1',
        email,
        name: email.split('@')[0],
        country: 'TR', // Default to Turkey
        favorites: []
      };
      
      localStorage.setItem('tawazon_user', JSON.stringify(mockUser));
      dispatch({ type: 'LOGIN_SUCCESS', payload: mockUser });
      return true;
    } catch (error) {
      dispatch({ type: 'LOGIN_FAILURE' });
      return false;
    }
  };

  const signup = async (email: string, password: string, name: string, country: string): Promise<boolean> => {
    dispatch({ type: 'LOGIN_START' });
    
    try {
      // Mock signup - in real app, this would be API call
      const newUser: User = {
        id: Date.now().toString(),
        email,
        name,
        country,
        favorites: []
      };
      
      localStorage.setItem('tawazon_user', JSON.stringify(newUser));
      dispatch({ type: 'LOGIN_SUCCESS', payload: newUser });
      return true;
    } catch (error) {
      dispatch({ type: 'LOGIN_FAILURE' });
      return false;
    }
  };

  const logout = () => {
    localStorage.removeItem('tawazon_user');
    dispatch({ type: 'LOGOUT' });
  };

  const addToFavorites = (productId: number) => {
    if (state.user && !state.user.favorites.includes(productId)) {
      const updatedFavorites = [...state.user.favorites, productId];
      const updatedUser = { ...state.user, favorites: updatedFavorites };
      localStorage.setItem('tawazon_user', JSON.stringify(updatedUser));
      dispatch({ type: 'UPDATE_USER', payload: { favorites: updatedFavorites } });
    }
  };

  const removeFromFavorites = (productId: number) => {
    if (state.user) {
      const updatedFavorites = state.user.favorites.filter(id => id !== productId);
      const updatedUser = { ...state.user, favorites: updatedFavorites };
      localStorage.setItem('tawazon_user', JSON.stringify(updatedUser));
      dispatch({ type: 'UPDATE_USER', payload: { favorites: updatedFavorites } });
    }
  };

  return (
    <AuthContext.Provider value={{ 
      state, 
      dispatch, 
      login, 
      signup, 
      logout, 
      addToFavorites, 
      removeFromFavorites 
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};