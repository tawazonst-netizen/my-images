import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

export interface Currency {
  code: string;
  symbol: string;
  rate: number;
}

interface CurrencyContextType {
  currency: Currency;
  setCurrency: (currency: Currency) => void;
  convertPrice: (usdPrice: number) => number;
  formatPrice: (usdPrice: number) => string;
  getShippingCost: (weight: number, country: string) => { cost: number; formatted: string };
}

const currencies: Record<string, Currency> = {
  USD: { code: 'USD', symbol: '$', rate: 1 },
  TRY: { code: 'TRY', symbol: '₺', rate: 30.5 }, // Dynamic rate - in real app, fetch from API
  EUR: { code: 'EUR', symbol: '€', rate: 0.92 }
};

const CurrencyContext = createContext<CurrencyContextType | null>(null);

export const CurrencyProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currency, setCurrency] = useState<Currency>(currencies.USD);

  useEffect(() => {
    // Detect user's country and set currency
    const detectCurrency = async () => {
      try {
        // In real app, use geolocation API or user preference
        const userCountry = localStorage.getItem('user_country') || 'US';
        
        if (userCountry === 'TR') {
          setCurrency(currencies.TRY);
        } else if (['DE', 'FR', 'IT', 'ES', 'NL', 'BE', 'AT'].includes(userCountry)) {
          setCurrency(currencies.EUR);
        } else {
          setCurrency(currencies.USD);
        }
      } catch (error) {
        setCurrency(currencies.USD);
      }
    };

    detectCurrency();
  }, []);

  const convertPrice = (usdPrice: number): number => {
    return usdPrice * currency.rate;
  };

  const formatPrice = (usdPrice: number): string => {
    const convertedPrice = convertPrice(usdPrice);
    return `${currency.symbol}${convertedPrice.toFixed(2)}`;
  };

  const getShippingCost = (weight: number, country: string): { cost: number; formatted: string } => {
    if (country === 'TR') {
      // Turkey: Fixed 125 TRY
      const costInTRY = 125;
      const costInUSD = costInTRY / currencies.TRY.rate;
      return {
        cost: currency.code === 'TRY' ? costInTRY : costInUSD * currency.rate,
        formatted: currency.code === 'TRY' ? '₺125.00' : formatPrice(costInUSD)
      };
    } else {
      // Outside Turkey: 30 USD base + 5 USD per additional kg
      const baseWeight = 1;
      const additionalWeight = Math.max(0, weight - baseWeight);
      const costInUSD = 30 + (additionalWeight * 5);
      
      return {
        cost: convertPrice(costInUSD),
        formatted: formatPrice(costInUSD)
      };
    }
  };

  return (
    <CurrencyContext.Provider value={{
      currency,
      setCurrency,
      convertPrice,
      formatPrice,
      getShippingCost
    }}>
      {children}
    </CurrencyContext.Provider>
  );
};

export const useCurrency = () => {
  const context = useContext(CurrencyContext);
  if (!context) {
    throw new Error('useCurrency must be used within a CurrencyProvider');
  }
  return context;
};