import React from 'react';
import { FileText, Shield, Users, AlertTriangle } from 'lucide-react';

const TermsOfUse = () => {
  return (
    <div className="py-8">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-50 to-green-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl font-bold text-gray-800 mb-6">شروط الاستخدام</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            القواعد والشروط التي تحكم استخدام موقع مكتبة توازن
          </p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Introduction */}
        <div className="card p-8 mb-8">
          <div className="flex items-center space-x-4 mb-6">
            <div className="bg-blue-100 p-3 rounded-lg">
              <FileText className="h-8 w-8 text-blue-600" />
            </div>
            <h2 className="text-3xl font-bold text-gray-800">مقدمة</h2>
          </div>
          <p className="text-lg text-gray-700 leading-relaxed mb-4">
            مرحباً بكم في موقع مكتبة توازن. باستخدامكم لهذا الموقع، فإنكم توافقون على الالتزام بهذه الشروط والأحكام. يرجى قراءة هذه الشروط بعناية قبل استخدام الموقع.
          </p>
          <p className="text-gray-600">
            آخر تحديث: يناير 2024
          </p>
        </div>

        {/* Website Usage */}
        <div className="card p-8 mb-8">
          <div className="flex items-center space-x-4 mb-6">
            <div className="bg-green-100 p-3 rounded-lg">
              <Users className="h-8 w-8 text-green-600" />
            </div>
            <h3 className="text-2xl font-bold text-gray-800">استخدام الموقع</h3>
          </div>
          <div className="space-y-4 text-gray-700">
            <h4 className="text-lg font-semibold text-gray-800">الاستخدام المسموح</h4>
            <ul className="space-y-2">
              <li>• تصفح المنتجات والمحتوى التعليمي</li>
              <li>• إجراء عمليات الشراء للاستخدام الشخصي</li>
              <li>• التواصل مع فريق خدمة العملاء</li>
              <li>• مشاركة المحتوى مع الإشارة للمصدر</li>
              <li>• استخدام المواد التعليمية للأغراض التعليمية</li>
            </ul>
            
            <h4 className="text-lg font-semibold text-gray-800 mt-6">الاستخدام المحظور</h4>
            <ul className="space-y-2">
              <li>• نسخ أو توزيع المحتوى بدون إذن</li>
              <li>• استخدام الموقع لأغراض تجارية غير مصرح بها</li>
              <li>• محاولة اختراق أو إلحاق الضرر بالموقع</li>
              <li>• نشر محتوى مسيء أو غير قانوني</li>
              <li>• انتهاك حقوق الملكية الفكرية</li>
            </ul>
          </div>
        </div>

        {/* Orders and Payments */}
        <div className="card p-8 mb-8">
          <h3 className="text-2xl font-bold text-gray-800 mb-6">الطلبات والمدفوعات</h3>
          <div className="space-y-4 text-gray-700">
            <div>
              <h4 className="text-lg font-semibold text-gray-800 mb-2">تأكيد الطلبات</h4>
              <p>جميع الطلبات تخضع للتأكيد والموافقة من قبل مكتبة توازن. نحتفظ بالحق في رفض أي طلب لأي سبب.</p>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold text-gray-800 mb-2">الأسعار</h4>
              <p>الأسعار المعروضة تشمل ضريبة القيمة المضافة حيثما ينطبق. نحتفظ بالحق في تغيير الأسعار دون إشعار مسبق.</p>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold text-gray-800 mb-2">طرق الدفع</h4>
              <p>نقبل الدفع عند الاستلام والبطاقات الائتمانية. جميع المعاملات المالية آمنة ومحمية.</p>
            </div>
          </div>
        </div>

        {/* Intellectual Property */}
        <div className="card p-8 mb-8">
          <div className="flex items-center space-x-4 mb-6">
            <div className="bg-yellow-100 p-3 rounded-lg">
              <Shield className="h-8 w-8 text-yellow-600" />
            </div>
            <h3 className="text-2xl font-bold text-gray-800">الملكية الفكرية</h3>
          </div>
          <div className="space-y-4 text-gray-700">
            <p>
              جميع المحتويات الموجودة على هذا الموقع، بما في ذلك النصوص والصور والتصاميم والشعارات، محمية بحقوق الطبع والنشر وتخص مكتبة توازن.
            </p>
            <p>
              لا يجوز نسخ أو توزيع أو تعديل أي محتوى من الموقع بدون إذن كتابي مسبق من مكتبة توازن.
            </p>
          </div>
        </div>

        {/* Liability */}
        <div className="card p-8 mb-8">
          <div className="flex items-center space-x-4 mb-6">
            <div className="bg-red-100 p-3 rounded-lg">
              <AlertTriangle className="h-8 w-8 text-red-600" />
            </div>
            <h3 className="text-2xl font-bold text-gray-800">المسؤولية</h3>
          </div>
          <div className="space-y-4 text-gray-700">
            <div>
              <h4 className="text-lg font-semibold text-gray-800 mb-2">مسؤولية المستخدم</h4>
              <ul className="space-y-2">
                <li>• ضمان دقة المعلومات المقدمة</li>
                <li>• الحفاظ على سرية بيانات الحساب</li>
                <li>• الاستخدام المسؤول للموقع</li>
                <li>• الالتزام بالقوانين المحلية</li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold text-gray-800 mb-2">مسؤولية مكتبة توازن</h4>
              <ul className="space-y-2">
                <li>• توفير منتجات عالية الجودة</li>
                <li>• حماية بيانات العملاء</li>
                <li>• تقديم خدمة عملاء ممتازة</li>
                <li>• الالتزام بمواعيد التسليم المحددة</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Changes to Terms */}
        <div className="card p-8 mb-8">
          <h3 className="text-2xl font-bold text-gray-800 mb-6">تعديل الشروط</h3>
          <p className="text-gray-700 leading-relaxed">
            نحتفظ بالحق في تعديل هذه الشروط والأحكام في أي وقت. سيتم إشعار المستخدمين بأي تغييرات جوهرية عبر الموقع أو البريد الإلكتروني. استمرار استخدام الموقع بعد التعديلات يعني موافقتكم على الشروط الجديدة.
          </p>
        </div>

        {/* Contact */}
        <div className="card p-8">
          <h3 className="text-2xl font-bold text-gray-800 mb-6">التواصل</h3>
          <p className="text-gray-700 mb-4">
            إذا كان لديكم أي أسئلة حول هذه الشروط والأحكام، يرجى التواصل معنا:
          </p>
          <div className="space-y-2 text-gray-700">
            <a href="tel:+905516749445" className="block hover:text-blue-600">
              📞 الهاتف: +90 551 674 9445
            </a>
            <a href="mailto:info@tawazonstore.com" className="block hover:text-blue-600">
              📧 البريد الإلكتروني: info@tawazonstore.com
            </a>
            <p>📍 العنوان: فاتح، إسطنبول، تركيا</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TermsOfUse;