import React from 'react';
import { BookOpen, ShoppingCart, MessageCircle, Search, CreditCard, Truck } from 'lucide-react';

const UserGuide = () => {
  return (
    <div className="py-8">
      {/* Header */}
      <div className="bg-gradient-to-r from-yellow-50 to-blue-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl font-bold text-gray-800 mb-6">دليل الاستخدام</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            دليل شامل لاستخدام موقع مكتبة توازن والاستفادة من جميع خدماتنا
          </p>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Quick Start */}
        <div className="card p-8 mb-8">
          <div className="flex items-center space-x-4 mb-6">
            <div className="bg-green-100 p-3 rounded-lg">
              <BookOpen className="h-8 w-8 text-green-600" />
            </div>
            <h2 className="text-3xl font-bold text-gray-800">البداية السريعة</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center p-6 bg-blue-50 rounded-xl">
              <div className="bg-blue-500 text-white w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">1</div>
              <h3 className="text-lg font-semibold text-gray-800 mb-2">تصفح المنتجات</h3>
              <p className="text-gray-600">اكتشف مجموعتنا الواسعة من الكتب والألعاب التعليمية</p>
            </div>
            <div className="text-center p-6 bg-green-50 rounded-xl">
              <div className="bg-green-500 text-white w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">2</div>
              <h3 className="text-lg font-semibold text-gray-800 mb-2">أضف للسلة</h3>
              <p className="text-gray-600">اختر المنتجات المناسبة وأضفها لسلة التسوق</p>
            </div>
            <div className="text-center p-6 bg-yellow-50 rounded-xl">
              <div className="bg-yellow-500 text-white w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">3</div>
              <h3 className="text-lg font-semibold text-gray-800 mb-2">اطلب واستلم</h3>
              <p className="text-gray-600">أكمل الطلب واستلم منتجاتك في المنزل</p>
            </div>
          </div>
        </div>

        {/* Browsing Products */}
        <div className="card p-8 mb-8">
          <div className="flex items-center space-x-4 mb-6">
            <div className="bg-blue-100 p-3 rounded-lg">
              <Search className="h-8 w-8 text-blue-600" />
            </div>
            <h3 className="text-2xl font-bold text-gray-800">تصفح المنتجات</h3>
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div>
              <h4 className="text-lg font-semibold text-gray-800 mb-4">طرق التصفح</h4>
              <div className="space-y-3">
                <div className="flex items-start space-x-3">
                  <div className="bg-blue-100 p-2 rounded-lg">
                    <span className="text-blue-600 font-bold">1</span>
                  </div>
                  <div>
                    <h5 className="font-semibold text-gray-800">حسب الفئة</h5>
                    <p className="text-gray-600 text-sm">اختر من الفئات الرئيسية: كتابي الأول، هيا نتعلم، الألعاب التعليمية</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="bg-green-100 p-2 rounded-lg">
                    <span className="text-green-600 font-bold">2</span>
                  </div>
                  <div>
                    <h5 className="font-semibold text-gray-800">حسب العمر</h5>
                    <p className="text-gray-600 text-sm">فلتر المنتجات حسب الفئة العمرية المناسبة لطفلك</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="bg-yellow-100 p-2 rounded-lg">
                    <span className="text-yellow-600 font-bold">3</span>
                  </div>
                  <div>
                    <h5 className="font-semibold text-gray-800">البحث المباشر</h5>
                    <p className="text-gray-600 text-sm">استخدم شريط البحث للعثور على منتج محدد</p>
                  </div>
                </div>
              </div>
            </div>
            <div>
              <h4 className="text-lg font-semibold text-gray-800 mb-4">معلومات المنتج</h4>
              <div className="bg-gray-50 p-4 rounded-lg">
                <ul className="space-y-2 text-gray-700">
                  <li>• <strong>الوصف:</strong> تفاصيل شاملة عن المنتج</li>
                  <li>• <strong>الفئة العمرية:</strong> العمر المناسب للاستخدام</li>
                  <li>• <strong>التقييمات:</strong> آراء العملاء السابقين</li>
                  <li>• <strong>الصور:</strong> صور عالية الجودة للمنتج</li>
                  <li>• <strong>السعر:</strong> السعر الحالي والخصومات</li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        {/* Shopping Cart */}
        <div className="card p-8 mb-8">
          <div className="flex items-center space-x-4 mb-6">
            <div className="bg-green-100 p-3 rounded-lg">
              <ShoppingCart className="h-8 w-8 text-green-600" />
            </div>
            <h3 className="text-2xl font-bold text-gray-800">سلة التسوق</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h4 className="text-lg font-semibold text-gray-800 mb-4">إضافة المنتجات</h4>
              <div className="space-y-3 text-gray-700">
                <p>• انقر على زر "أضف للسلة" في صفحة المنتج</p>
                <p>• يمكنك تغيير الكمية من صفحة السلة</p>
                <p>• راجع المنتجات قبل إتمام الطلب</p>
                <p>• احذف المنتجات غير المرغوبة</p>
              </div>
            </div>
            <div>
              <h4 className="text-lg font-semibold text-gray-800 mb-4">مراجعة الطلب</h4>
              <div className="bg-blue-50 p-4 rounded-lg">
                <ul className="space-y-2 text-gray-700">
                  <li>✓ تأكد من صحة المنتجات والكميات</li>
                  <li>✓ راجع إجمالي المبلغ</li>
                  <li>✓ تحقق من تطبيق الخصومات</li>
                  <li>✓ تأكد من الشحن المجاني (للطلبات فوق 150 ر.س)</li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        {/* Checkout Process */}
        <div className="card p-8 mb-8">
          <div className="flex items-center space-x-4 mb-6">
            <div className="bg-yellow-100 p-3 rounded-lg">
              <CreditCard className="h-8 w-8 text-yellow-600" />
            </div>
            <h3 className="text-2xl font-bold text-gray-800">إتمام الطلب</h3>
          </div>
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="text-lg font-semibold text-gray-800 mb-3">معلومات الشحن</h4>
                <div className="space-y-2 text-gray-700">
                  <p>• الاسم الكامل (مطلوب)</p>
                  <p>• رقم الهاتف (مطلوب)</p>
                  <p>• العنوان التفصيلي (مطلوب)</p>
                  <p>• المدينة والدولة</p>
                  <p>• البريد الإلكتروني (اختياري)</p>
                </div>
              </div>
              <div>
                <h4 className="text-lg font-semibold text-gray-800 mb-3">طرق الدفع</h4>
                <div className="space-y-3">
                  <div className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg">
                    <Truck className="h-6 w-6 text-green-600" />
                    <div>
                      <p className="font-semibold text-green-800">الدفع عند الاستلام</p>
                      <p className="text-sm text-green-700">ادفع نقداً عند وصول الطلب</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3 p-3 bg-blue-50 rounded-lg">
                    <CreditCard className="h-6 w-6 text-blue-600" />
                    <div>
                      <p className="font-semibold text-blue-800">البطاقة الائتمانية</p>
                      <p className="text-sm text-blue-700">فيزا، ماستركارد (آمن ومشفر)</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Contact Support */}
        <div className="card p-8 mb-8">
          <div className="flex items-center space-x-4 mb-6">
            <div className="bg-purple-100 p-3 rounded-lg">
              <MessageCircle className="h-8 w-8 text-purple-600" />
            </div>
            <h3 className="text-2xl font-bold text-gray-800">التواصل والدعم</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="text-center p-4 bg-green-50 rounded-xl">
              <div className="bg-green-500 p-3 rounded-full w-fit mx-auto mb-3">
                <MessageCircle className="h-6 w-6 text-white" />
              </div>
              <h4 className="font-semibold text-gray-800 mb-2">واتساب</h4>
              <p className="text-sm text-gray-600 mb-3">تواصل سريع ومباشر</p>
              <a href="https://wa.me/905516749445?text=مرحباً%20أحتاج%20مساعدة%20في%20استخدام%20الموقع" 
                 target="_blank" rel="noopener noreferrer" className="text-green-600 font-semibold hover:underline">
                +90 551 674 9445
              </a>
            </div>
            <div className="text-center p-4 bg-blue-50 rounded-xl">
              <div className="bg-blue-500 p-3 rounded-full w-fit mx-auto mb-3">
                <MessageCircle className="h-6 w-6 text-white" />
              </div>
              <h4 className="font-semibold text-gray-800 mb-2">البريد الإلكتروني</h4>
              <p className="text-sm text-gray-600 mb-3">للاستفسارات التفصيلية</p>
              <a href="mailto:info@tawazonstore.com" className="text-blue-600 font-semibold hover:underline">
                info@tawazonstore.com
              </a>
            </div>
            <div className="text-center p-4 bg-yellow-50 rounded-xl">
              <div className="bg-yellow-500 p-3 rounded-full w-fit mx-auto mb-3">
                <MessageCircle className="h-6 w-6 text-white" />
              </div>
              <h4 className="font-semibold text-gray-800 mb-2">الهاتف</h4>
              <p className="text-sm text-gray-600 mb-3">اتصال مباشر</p>
              <a href="tel:+905516749445" className="text-yellow-600 font-semibold hover:underline">
                +90 551 674 9445
              </a>
            </div>
            <div className="text-center p-4 bg-green-50 rounded-xl">
              <div className="bg-green-500 p-3 rounded-full w-fit mx-auto mb-3">
                <MessageCircle className="h-6 w-6 text-white" />
              </div>
              <h4 className="font-semibold text-gray-800 mb-2">دعم فني</h4>
              <p className="text-sm text-gray-600 mb-3">مساعدة تقنية</p>
              <a href="https://wa.me/905516749445?text=أحتاج%20مساعدة%20تقنية" 
                 target="_blank" rel="noopener noreferrer" className="text-green-600 font-semibold hover:underline">
                واتساب
              </a>
            </div>
          </div>
        </div>

        {/* FAQ Quick Access */}
        <div className="card p-8">
          <h3 className="text-2xl font-bold text-gray-800 mb-6">أسئلة شائعة</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="text-lg font-semibold text-gray-800 mb-3">حول الطلبات</h4>
              <ul className="space-y-2 text-gray-700">
                <li>• كم تستغرق عملية التوصيل؟</li>
                <li>• هل يمكنني تغيير طلبي بعد التأكيد؟</li>
                <li>• ما هي تكلفة الشحن؟</li>
                <li>• كيف أتتبع طلبي؟</li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold text-gray-800 mb-3">حول المنتجات</h4>
              <ul className="space-y-2 text-gray-700">
                <li>• كيف أختار المنتج المناسب لطفلي؟</li>
                <li>• هل المنتجات آمنة للأطفال؟</li>
                <li>• هل يمكنني إرجاع المنتج؟</li>
                <li>• هل تقدمون ضمان على المنتجات؟</li>
              </ul>
            </div>
          </div>
          <div className="mt-6 text-center">
            <button 
              onClick={() => window.location.href = '/faq'}
              className="btn-primary"
            >
              عرض جميع الأسئلة الشائعة
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserGuide;