import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Star, ShoppingCart, Heart, Share2, Truck, Shield, ArrowLeft, User, ZoomIn, Plus, Minus } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import { useCurrency } from '../context/CurrencyContext';
import LoginModal from '../components/LoginModal';

const ProductDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { dispatch } = useCart();
  const { state: authState, addToFavorites, removeFromFavorites } = useAuth();
  const { formatPrice, getShippingCost } = useCurrency();
  const [selectedImage, setSelectedImage] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [activeTab, setActiveTab] = useState('description');
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [zoomedImage, setZoomedImage] = useState<string | null>(null);
  const [newReview, setNewReview] = useState({ rating: 5, comment: '' });

  // Enhanced product data with weights and detailed information
  const products = [
    {
      id: 1,
      title: 'كتابي الأول في التعرف على الألوان',
      titleEn: 'My First Book: Learning Colors',
      priceUSD: 15,
      images: [
        'https://images.pexels.com/photos/4473775/pexels-photo-4473775.jpeg?auto=compress&cs=tinysrgb&w=800',
        'https://images.pexels.com/photos/4491461/pexels-photo-4491461.jpeg?auto=compress&cs=tinysrgb&w=800',
        'https://images.pexels.com/photos/5428836/pexels-photo-5428836.jpeg?auto=compress&cs=tinysrgb&w=800',
        'https://images.pexels.com/photos/4473409/pexels-photo-4473409.jpeg?auto=compress&cs=tinysrgb&w=800'
      ],
      rating: 4.8,
      reviews: 124,
      category: 'first-books',
      ageRange: '2-4 سنوات',
      weight: 0.8,
      description: 'كتاب للطفولة المبكرة (عمر 2-4 سنوات). يقدم 10 ألوان مع أنشطة تفاعلية ورسوم توضيحية. يساعد الأطفال على التعرف على الألوان وتسميتها في الحياة اليومية.',
      descriptionEn: 'Book for early childhood (ages 2–4). Introduces 10 colors with interactive activities and illustrations. Helps children recognize and name colors in daily life.',
      features: [
        'أصوات تفاعلية لكل لون',
        'رسوم ملونة وجذابة عالية الجودة',
        'مواد آمنة ومقاومة للتلف',
        'أنشطة تفاعلية متنوعة',
        'يساعد في تطوير المهارات البصرية'
      ],
      specifications: {
        'الأبعاد': '20 × 25 سم',
        'عدد الصفحات': '32 صفحة',
        'الوزن': '0.8 كيلو',
        'المواد': 'ورق مقوى آمن',
        'اللغة': 'العربية',
        'العمر المناسب': '2-4 سنوات'
      }
    },
    {
      id: 2,
      title: 'لعبة الأرقام السحرية',
      titleEn: 'Magic Numbers Game',
      priceUSD: 25,
      images: [
        'https://images.pexels.com/photos/8613089/pexels-photo-8613089.jpeg?auto=compress&cs=tinysrgb&w=800',
        'https://images.pexels.com/photos/4491461/pexels-photo-4491461.jpeg?auto=compress&cs=tinysrgb&w=800'
      ],
      rating: 4.9,
      reviews: 89,
      category: 'games',
      ageRange: '3-6 سنوات',
      weight: 1.2,
      description: 'لعبة تعليمية تفاعلية لتعلم الأرقام والعد بطريقة ممتعة ومشوقة.',
      descriptionEn: 'Interactive educational game for learning numbers and counting in a fun way.',
      features: [
        'تعليم الأرقام من 1 إلى 20',
        'ألعاب تفاعلية متنوعة',
        'تطوير مهارات الحساب',
        'مواد عالية الجودة',
        'مناسب للعب الجماعي'
      ],
      specifications: {
        'الأبعاد': '30 × 30 سم',
        'الوزن': '1.2 كيلو',
        'المحتويات': 'بطاقات أرقام + لوحة لعب',
        'المواد': 'بلاستيك آمن',
        'اللغة': 'العربية والإنجليزية',
        'العمر المناسب': '3-6 سنوات'
      }
    },
    {
      id: 3,
      title: 'كتابي الأول في التعرف على الأشكال',
      titleEn: 'My First Book: Learning Shapes',
      priceUSD: 18,
      images: [
        'https://images.pexels.com/photos/5428836/pexels-photo-5428836.jpeg?auto=compress&cs=tinysrgb&w=800'
      ],
      rating: 4.7,
      reviews: 67,
      category: 'first-books',
      ageRange: '2-4 سنوات',
      weight: 0.7,
      description: 'كتاب تفاعلي لتعليم الأشكال الهندسية الأساسية.',
      descriptionEn: 'Interactive book for teaching basic geometric shapes.',
      features: [
        'تعليم الأشكال الأساسية',
        'أنشطة تفاعلية',
        'رسوم توضيحية واضحة'
      ],
      specifications: {
        'الأبعاد': '20 × 25 سم',
        'الوزن': '0.7 كيلو',
        'عدد الصفحات': '28 صفحة',
        'المواد': 'ورق مقوى آمن',
        'اللغة': 'العربية',
        'العمر المناسب': '2-4 سنوات'
      }
    }
  ];

  const product = products.find(p => p.id === parseInt(id || '1')) || products[0];

  const reviews = [
    {
      id: 1,
      name: 'عائشة، إسطنبول',
      nameEn: 'Aisha, Istanbul',
      rating: 5,
      date: '2024-01-15',
      comment: 'طفلي أحب الإشارة إلى الألوان الصحيحة، كتاب جذاب جداً!',
      commentEn: 'My child loved pointing to the right colors, very engaging!',
      helpful: 12,
      verified: true
    },
    {
      id: 2,
      name: 'عمر، دبي',
      nameEn: 'Omar, Dubai',
      rating: 4,
      date: '2024-01-10',
      comment: 'جودة ممتازة وتصميم بسيط، مثالي للأطفال الصغار.',
      commentEn: 'Great quality and simple design, perfect for toddlers.',
      helpful: 8,
      verified: true
    },
    {
      id: 3,
      name: 'فاطمة، الرياض',
      nameEn: 'Fatima, Riyadh',
      rating: 5,
      date: '2024-01-05',
      comment: 'ابنتي تعلمت الألوان بسرعة مع هذا الكتاب الرائع.',
      commentEn: 'My daughter learned colors quickly with this amazing book.',
      helpful: 15,
      verified: true
    }
  ];

  const relatedProducts = products.filter(p => p.id !== product.id && p.category === product.category).slice(0, 3);

  const addToCart = () => {
    for (let i = 0; i < quantity; i++) {
      dispatch({
        type: 'ADD_ITEM',
        payload: {
          id: product.id,
          title: product.title,
          price: product.priceUSD,
          originalPrice: product.priceUSD * 1.2,
          image: product.images[0],
          ageRange: product.ageRange
        }
      });
    }
  };

  const handleFavoriteToggle = () => {
    if (!authState.isAuthenticated) {
      setShowLoginModal(true);
      return;
    }

    const isFavorite = authState.user?.favorites.includes(product.id);
    if (isFavorite) {
      removeFromFavorites(product.id);
    } else {
      addToFavorites(product.id);
    }
  };

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!authState.isAuthenticated) {
      setShowLoginModal(true);
      return;
    }
    // In real app, submit review to backend
    alert('تم إرسال تقييمك بنجاح!');
    setNewReview({ rating: 5, comment: '' });
  };

  const userCountry = authState.user?.country || 'TR';
  const shippingInfo = getShippingCost(product.weight, userCountry);
  const isFavorite = authState.user?.favorites.includes(product.id) || false;

  return (
    <div className="py-8">
      {/* Breadcrumb */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-8">
        <div className="flex items-center space-x-2 text-sm text-gray-600">
          <button onClick={() => navigate('/')} className="hover:text-blue-600">الرئيسية</button>
          <span>/</span>
          <button onClick={() => navigate('/shop')} className="hover:text-blue-600">المتجر</button>
          <span>/</span>
          <span className="text-gray-800">{product.title}</span>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Product Images */}
          <div>
            <div className="mb-4 relative">
              <img
                src={product.images[selectedImage]}
                alt={product.title}
                className="w-full h-96 object-cover rounded-2xl shadow-lg cursor-zoom-in"
                onClick={() => setZoomedImage(product.images[selectedImage])}
              />
              <button
                onClick={() => setZoomedImage(product.images[selectedImage])}
                className="absolute top-4 right-4 bg-white p-2 rounded-full shadow-lg hover:bg-gray-100"
              >
                <ZoomIn className="h-5 w-5 text-gray-600" />
              </button>
            </div>
            <div className="flex space-x-2 overflow-x-auto">
              {product.images.map((image, index) => (
                <button
                  key={index}
                  onClick={() => setSelectedImage(index)}
                  className={`flex-shrink-0 w-20 h-20 rounded-lg overflow-hidden border-2 ${
                    selectedImage === index ? 'border-blue-500' : 'border-gray-200'
                  }`}
                >
                  <img src={image} alt="" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          </div>

          {/* Product Info */}
          <div>
            <div className="mb-6">
              <h1 className="text-3xl font-bold text-gray-800 mb-2">{product.title}</h1>
              <p className="text-lg text-gray-600 mb-4">{product.description}</p>
              
              {/* Rating */}
              <div className="flex items-center space-x-4 mb-4">
                <div className="flex text-yellow-400">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`h-5 w-5 ${i < Math.floor(product.rating) ? 'fill-current' : ''}`}
                    />
                  ))}
                </div>
                <span className="text-gray-600">({product.reviews} تقييم)</span>
              </div>

              {/* Price */}
              <div className="flex items-center space-x-4 mb-6">
                <span className="text-3xl font-bold text-blue-600">{formatPrice(product.priceUSD)}</span>
                <span className="bg-green-100 text-green-600 px-3 py-1 rounded-full text-sm font-bold">
                  شحن: {shippingInfo.formatted}
                </span>
              </div>

              {/* Weight & Age Range */}
              <div className="flex items-center space-x-4 mb-6">
                <span className="bg-blue-100 text-blue-700 px-4 py-2 rounded-full font-medium">
                  العمر المناسب: {product.ageRange}
                </span>
                <span className="bg-gray-100 text-gray-700 px-4 py-2 rounded-full font-medium">
                  الوزن: {product.weight} كيلو
                </span>
              </div>
            </div>

            {/* Quantity & Add to Cart */}
            <div className="mb-8">
              <div className="flex items-center space-x-4 mb-4">
                <label className="text-lg font-semibold text-gray-800">الكمية:</label>
                <div className="flex items-center border border-gray-300 rounded-lg">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="px-3 py-2 hover:bg-gray-100"
                  >
                    <Minus className="h-4 w-4" />
                  </button>
                  <span className="px-4 py-2 font-semibold">{quantity}</span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="px-3 py-2 hover:bg-gray-100"
                  >
                    <Plus className="h-4 w-4" />
                  </button>
                </div>
              </div>

              <div className="flex space-x-4">
                <button
                  onClick={addToCart}
                  className="btn-primary flex-1 flex items-center justify-center space-x-2"
                >
                  <ShoppingCart className="h-5 w-5" />
                  <span>أضف للسلة</span>
                </button>
                <button 
                  onClick={handleFavoriteToggle}
                  className={`p-3 rounded-xl transition-colors ${
                    isFavorite 
                      ? 'bg-red-100 text-red-600' 
                      : 'bg-gray-200 hover:bg-gray-300 text-gray-600'
                  }`}
                >
                  <Heart className={`h-6 w-6 ${isFavorite ? 'fill-current' : ''}`} />
                </button>
                <button className="bg-gray-200 hover:bg-gray-300 p-3 rounded-xl">
                  <Share2 className="h-6 w-6 text-gray-600" />
                </button>
              </div>
            </div>

            {/* Features */}
            <div className="mb-8">
              <div className="flex items-center space-x-4 text-sm text-gray-600">
                <div className="flex items-center space-x-2">
                  <Truck className="h-4 w-4" />
                  <span>شحن إلى {userCountry === 'TR' ? 'تركيا' : 'خارج تركيا'}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Shield className="h-4 w-4" />
                  <span>ضمان الجودة</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Product Details Tabs */}
        <div className="mt-16">
          <div className="border-b border-gray-200">
            <nav className="flex space-x-8">
              {[
                { id: 'description', name: 'الوصف' },
                { id: 'features', name: 'المميزات' },
                { id: 'specifications', name: 'المواصفات' },
                { id: 'reviews', name: `التقييمات (${reviews.length})` }
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`py-4 px-1 border-b-2 font-medium text-sm ${
                    activeTab === tab.id
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700'
                  }`}
                >
                  {tab.name}
                </button>
              ))}
            </nav>
          </div>

          <div className="py-8">
            {activeTab === 'description' && (
              <div className="prose max-w-none">
                <p className="text-lg text-gray-700 leading-relaxed">{product.description}</p>
              </div>
            )}

            {activeTab === 'features' && (
              <div>
                <h3 className="text-xl font-bold text-gray-800 mb-4">مميزات المنتج</h3>
                <ul className="space-y-2">
                  {product.features.map((feature, index) => (
                    <li key={index} className="flex items-center space-x-2">
                      <span className="w-2 h-2 bg-blue-500 rounded-full"></span>
                      <span className="text-gray-700">{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {activeTab === 'specifications' && (
              <div>
                <h3 className="text-xl font-bold text-gray-800 mb-4">المواصفات التقنية</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {Object.entries(product.specifications).map(([key, value]) => (
                    <div key={key} className="flex justify-between py-2 border-b border-gray-200">
                      <span className="font-semibold text-gray-800">{key}:</span>
                      <span className="text-gray-600">{value}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'reviews' && (
              <div>
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-xl font-bold text-gray-800">تقييمات العملاء</h3>
                  {authState.isAuthenticated ? (
                    <button 
                      onClick={() => setActiveTab('write-review')}
                      className="btn-secondary"
                    >
                      اكتب تقييماً
                    </button>
                  ) : (
                    <button 
                      onClick={() => setShowLoginModal(true)}
                      className="btn-secondary"
                    >
                      سجل دخولك لكتابة تقييم
                    </button>
                  )}
                </div>
                
                <div className="space-y-6">
                  {reviews.map((review) => (
                    <div key={review.id} className="card p-6">
                      <div className="flex items-start space-x-4">
                        <div className="bg-gray-200 w-12 h-12 rounded-full flex items-center justify-center">
                          <User className="h-6 w-6 text-gray-600" />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center space-x-4 mb-2">
                            <h4 className="font-semibold text-gray-800">{review.name}</h4>
                            <div className="flex text-yellow-400">
                              {[...Array(5)].map((_, i) => (
                                <Star
                                  key={i}
                                  className={`h-4 w-4 ${i < review.rating ? 'fill-current' : ''}`}
                                />
                              ))}
                            </div>
                            <span className="text-sm text-gray-500">{review.date}</span>
                            {review.verified && (
                              <span className="bg-green-100 text-green-600 px-2 py-1 rounded-full text-xs">
                                مشتري موثق
                              </span>
                            )}
                          </div>
                          <p className="text-gray-700 mb-2">{review.comment}</p>
                          <button className="text-sm text-gray-500 hover:text-blue-600">
                            مفيد ({review.helpful})
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'write-review' && authState.isAuthenticated && (
              <div>
                <h3 className="text-xl font-bold text-gray-800 mb-6">اكتب تقييمك</h3>
                <form onSubmit={handleReviewSubmit} className="space-y-4">
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      التقييم
                    </label>
                    <div className="flex space-x-1">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          type="button"
                          onClick={() => setNewReview({ ...newReview, rating: star })}
                          className={`text-2xl ${
                            star <= newReview.rating ? 'text-yellow-400' : 'text-gray-300'
                          }`}
                        >
                          ★
                        </button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      تعليقك
                    </label>
                    <textarea
                      value={newReview.comment}
                      onChange={(e) => setNewReview({ ...newReview, comment: e.target.value })}
                      rows={4}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="شاركنا تجربتك مع هذا المنتج..."
                      required
                    />
                  </div>
                  <div className="flex space-x-4">
                    <button type="submit" className="btn-primary">
                      إرسال التقييم
                    </button>
                    <button 
                      type="button"
                      onClick={() => setActiveTab('reviews')}
                      className="btn-secondary"
                    >
                      إلغاء
                    </button>
                  </div>
                </form>
              </div>
            )}
          </div>
        </div>

        {/* Related Products */}
        {relatedProducts.length > 0 && (
          <div className="mt-16">
            <h3 className="text-2xl font-bold text-gray-800 mb-8">منتجات ذات صلة</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {relatedProducts.map((relatedProduct) => (
                <div key={relatedProduct.id} className="card p-6">
                  <img
                    src={relatedProduct.images[0]}
                    alt={relatedProduct.title}
                    className="w-full h-48 object-cover rounded-xl mb-4"
                  />
                  <h4 className="font-bold text-gray-800 mb-2">{relatedProduct.title}</h4>
                  <div className="flex items-center space-x-2 mb-2">
                    <span className="text-lg font-bold text-blue-600">
                      {formatPrice(relatedProduct.priceUSD)}
                    </span>
                  </div>
                  <button
                    onClick={() => navigate(`/product/${relatedProduct.id}`)}
                    className="w-full btn-primary"
                  >
                    عرض المنتج
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Image Zoom Modal */}
      {zoomedImage && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-75 z-50 flex items-center justify-center p-4"
          onClick={() => setZoomedImage(null)}
        >
          <div className="relative max-w-4xl max-h-full">
            <img
              src={zoomedImage}
              alt="Zoomed product"
              className="max-w-full max-h-full object-contain rounded-lg"
            />
            <button
              onClick={() => setZoomedImage(null)}
              className="absolute top-4 right-4 bg-white p-2 rounded-full shadow-lg hover:bg-gray-100"
            >
              <X className="h-6 w-6 text-gray-600" />
            </button>
          </div>
        </div>
      )}

      {/* Login Modal */}
      <LoginModal isOpen={showLoginModal} onClose={() => setShowLoginModal(false)} />
    </div>
  );
};

export default ProductDetail;