import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Calendar, User, ArrowLeft, Clock } from 'lucide-react';

const Blog = () => {
  const navigate = useNavigate();


  const posts = [
    {
      id: 1,
      title: 'كيفية تعليم القراءة المبكرة للأطفال',
      excerpt: 'دليل شامل للأهالي حول أفضل الطرق لتعليم القراءة للأطفال في سن مبكرة...',
      image: 'https://images.pexels.com/photos/4491461/pexels-photo-4491461.jpeg?auto=compress&cs=tinysrgb&w=600',
      author: 'د. فاطمة الزهراني',
      date: '2024-01-15',
      readTime: '5 دقائق',
      category: 'نصائح للأهالي'
    },
    {
      id: 2,
      title: 'أهمية الكتب التفاعلية في التعليم',
      excerpt: 'تعرف على فوائد الكتب التفاعلية وكيف تساعد في تطوير مهارات الطفل المعرفية...',
      image: 'https://images.pexels.com/photos/5428836/pexels-photo-5428836.jpeg?auto=compress&cs=tinysrgb&w=600',
      author: 'أ. أحمد الشامي',
      date: '2024-01-10',
      readTime: '7 دقائق',
      category: 'التعليم التفاعلي'
    },
    {
      id: 3,
      title: 'دور اللعب في التعلم المبكر',
      excerpt: 'كيف يمكن للعب أن يكون أداة تعليمية قوية ويساعد في تنمية مهارات الطفل...',
      image: 'https://images.pexels.com/photos/8613089/pexels-photo-8613089.jpeg?auto=compress&cs=tinysrgb&w=600',
      author: 'أ. نورا العلي',
      date: '2024-01-08',
      readTime: '6 دقائق',
      category: 'التعلم باللعب'
    },
    {
      id: 4,
      title: 'اختيار الكتاب المناسب لعمر طفلك',
      excerpt: 'دليل عملي لاختيار الكتب المناسبة لكل مرحلة عمرية وتطوير حب القراءة...',
      image: 'https://images.pexels.com/photos/4473409/pexels-photo-4473409.jpeg?auto=compress&cs=tinysrgb&w=600',
      author: 'د. فاطمة الزهراني',
      date: '2024-01-05',
      readTime: '4 دقائق',
      category: 'اختيار الكتب'
    },
    {
      id: 5,
      title: 'تطوير المهارات اللغوية من خلال القصص',
      excerpt: 'كيف تساعد القصص التفاعلية في تطوير المفردات والمهارات اللغوية للطفل...',
      image: 'https://images.pexels.com/photos/8471904/pexels-photo-8471904.jpeg?auto=compress&cs=tinysrgb&w=600',
      author: 'أ. أحمد الشامي',
      date: '2024-01-01',
      readTime: '8 دقائق',
      category: 'تطوير اللغة'
    },
    {
      id: 6,
      title: 'بناء روتين القراءة اليومي',
      excerpt: 'نصائح عملية لبناء عادة القراءة اليومية وجعلها جزءاً ممتعاً من يوم الطفل...',
      image: 'https://images.pexels.com/photos/4474035/pexels-photo-4474035.jpeg?auto=compress&cs=tinysrgb&w=600',
      author: 'أ. نورا العلي',
      date: '2023-12-28',
      readTime: '5 دقائق',
      category: 'عادات القراءة'
    }
  ];

  return (
    <div className="py-8">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-50 to-green-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl font-bold text-gray-800 mb-6">المحتوى التعليمي</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            مقالات ونصائح متخصصة للأهالي والمعلمين حول التعليم المبكر وأفضل الممارسات التربوية
          </p>
        </div>
      </div>

      {/* Featured Article */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="card p-8 mb-16">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
            <div>
              <span className="bg-blue-100 text-blue-600 px-3 py-1 rounded-full text-sm font-medium mb-4 inline-block">
                مقال مميز
              </span>
              <h2 className="text-3xl font-bold text-gray-800 mb-4">
                كيفية تعليم القراءة المبكرة للأطفال
              </h2>
              <p className="text-gray-600 text-lg mb-6 leading-relaxed">
                دليل شامل للأهالي حول أفضل الطرق والأساليب لتعليم القراءة للأطفال في سن مبكرة، 
                مع نصائح عملية وأمثلة واقعية من تجارب ناجحة.
              </p>
              <div className="flex items-center space-x-6 text-sm text-gray-500 mb-6">
                <div className="flex items-center space-x-2">
                  <User className="h-4 w-4" />
                  <span>د. فاطمة الزهراني</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Calendar className="h-4 w-4" />
                  <span>15 يناير 2024</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Clock className="h-4 w-4" />
                  <span>5 دقائق</span>
                </div>
              </div>
              <button className="btn-primary flex items-center space-x-2">
                <span>اقرأ المقال</span>
                <ArrowLeft className="h-5 w-5" />
              </button>
            </div>
            <div>
              <img
                src={posts[0].image}
                alt={posts[0].title}
                className="w-full h-80 object-cover rounded-xl shadow-lg"
              />
            </div>
          </div>
        </div>

        {/* Articles Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {posts.slice(1).map((post) => (
            <article key={post.id} className="card p-6 group cursor-pointer"
              onClick={() => navigate(`/blog/${post.id}`)}>
              {/* Article Image */}
              <div className="relative mb-6">
                <img
                  src={post.image}
                  alt={post.title}
                  className="w-full h-48 object-cover rounded-xl"
                />
                <span className="absolute top-3 right-3 bg-white text-blue-600 px-3 py-1 rounded-full text-sm font-medium">
                  {post.category}
                </span>
              </div>

              {/* Article Content */}
              <div>
                <h3 className="text-xl font-bold text-gray-800 mb-3 group-hover:text-blue-600 transition-colors">
                  {post.title}
                </h3>
                <p className="text-gray-600 mb-4 leading-relaxed">
                  {post.excerpt}
                </p>

                {/* Article Meta */}
                <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                  <div className="flex items-center space-x-2">
                    <User className="h-4 w-4" />
                    <span>{post.author}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Clock className="h-4 w-4" />
                    <span>{post.readTime}</span>
                  </div>
                </div>

                <button className="text-blue-600 font-semibold hover:text-blue-700 transition-colors flex items-center space-x-2">
                  <span>اقرأ المزيد</span>
                  <ArrowLeft className="h-4 w-4" />
                </button>
              </div>
            </article>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Blog;