import React from 'react';
import { Target, Heart, Users, Award } from 'lucide-react';

const About = () => {
  return (
    <div className="py-20">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-50 to-green-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-5xl font-bold text-gray-800 mb-6">من نحن</h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              مكتبة توازن.. رائدة في مجال التعليم المبكر والكتب التفاعلية للأطفال
            </p>
          </div>
        </div>
      </section>

      {/* Vision & Mission */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-3xl font-bold text-gray-800 mb-6 flex items-center">
                <Target className="h-8 w-8 text-blue-500 ml-3" />
                رؤيتنا
              </h2>
              <p className="text-lg text-gray-700 leading-relaxed mb-8">
                نسعى لأن نكون الشريك الأول للأهالي والمربين في رحلة التعليم المبكر، من خلال تقديم محتوى تعليمي عالي الجودة يحقق التوازن المثالي بين التعلم والمتعة.
              </p>
              
              <h2 className="text-3xl font-bold text-gray-800 mb-6 flex items-center">
                <Heart className="h-8 w-8 text-red-500 ml-3" />
                مهمتنا
              </h2>
              <p className="text-lg text-gray-700 leading-relaxed">
                تطوير وإنتاج مواد تعليمية تفاعلية تساعد الأطفال على بناء أسس قوية في التعلم، مع التركيز على تنمية مهارات القراءة والكتابة والتفكير النقدي في بيئة محفزة وداعمة.
              </p>
            </div>
            <div>
              <img
                src="https://images.pexels.com/photos/8471904/pexels-photo-8471904.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="أطفال يتعلمون"
                className="w-full rounded-2xl shadow-xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">قيمنا</h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                icon: <Heart className="h-8 w-8" />,
                title: 'الجودة',
                description: 'نلتزم بأعلى معايير الجودة في جميع منتجاتنا'
              },
              {
                icon: <Users className="h-8 w-8" />,
                title: 'التفاعل',
                description: 'نشجع على التفاعل والمشاركة في عملية التعلم'
              },
              {
                icon: <Target className="h-8 w-8" />,
                title: 'التوازن',
                description: 'نحقق التوازن المثالي بين التعليم والترفيه'
              },
              {
                icon: <Award className="h-8 w-8" />,
                title: 'التميز',
                description: 'نسعى للتميز في كل ما نقدمه لأطفالكم'
              }
            ].map((value, index) => (
              <div key={index} className="card p-6 text-center">
                <div className="bg-blue-100 text-blue-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  {value.icon}
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-3">{value.title}</h3>
                <p className="text-gray-600">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">فريقنا</h2>
            <p className="text-lg text-gray-600">
              مجموعة من المختصين في التعليم المبكر وتطوير المحتوى التعليمي
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                name: 'دكتورة فاطمة الزهراني',
                role: 'مؤسسة ومديرة المحتوى',
                image: 'https://images.pexels.com/photos/3769021/pexels-photo-3769021.jpeg?auto=compress&cs=tinysrgb&w=400',
                bio: 'دكتوراه في التعليم المبكر، 15 عام خبرة'
              },
              {
                name: 'أستاذ أحمد الشامي',
                role: 'مطور المناهج التفاعلية',
                image: 'https://images.pexels.com/photos/5212345/pexels-photo-5212345.jpeg?auto=compress&cs=tinysrgb&w=400',
                bio: 'متخصص في التكنولوجيا التعليمية، 10 سنوات خبرة'
              },
              {
                name: 'الأستاذة نورا العلي',
                role: 'مستشارة تربوية',
                image: 'https://images.pexels.com/photos/4474047/pexels-photo-4474047.jpeg?auto=compress&cs=tinysrgb&w=400',
                bio: 'ماجستير في علم النفس التربوي، 12 سنة خبرة'
              }
            ].map((member, index) => (
              <div key={index} className="card p-6 text-center">
                <img
                  src={member.image}
                  alt={member.name}
                  className="w-24 h-24 rounded-full mx-auto mb-4 object-cover"
                />
                <h3 className="text-xl font-bold text-gray-800 mb-2">{member.name}</h3>
                <p className="text-blue-600 font-semibold mb-3">{member.role}</p>
                <p className="text-gray-600">{member.bio}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-gradient-to-r from-blue-500 to-green-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center text-white">
            {[
              { number: '500+', label: 'كتاب تفاعلي' },
              { number: '10,000+', label: 'طفل سعيد' },
              { number: '15+', label: 'سنة خبرة' },
              { number: '99%', label: 'رضا العملاء' }
            ].map((stat, index) => (
              <div key={index} className="transform hover:scale-105 transition-transform duration-300">
                <h3 className="text-4xl md:text-5xl font-bold mb-2">{stat.number}</h3>
                <p className="text-lg opacity-90">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;