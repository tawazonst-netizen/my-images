import React from 'react';
import { Lock, Eye, Database, Shield } from 'lucide-react';

const PrivacyPolicy = () => {
  return (
    <div className="py-8">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-50 to-green-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl font-bold text-gray-800 mb-6">سياسة الخصوصية</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            نحن ملتزمون بحماية خصوصيتكم وأمان بياناتكم الشخصية
          </p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Introduction */}
        <div className="card p-8 mb-8">
          <div className="flex items-center space-x-4 mb-6">
            <div className="bg-blue-100 p-3 rounded-lg">
              <Lock className="h-8 w-8 text-blue-600" />
            </div>
            <h2 className="text-3xl font-bold text-gray-800">التزامنا بالخصوصية</h2>
          </div>
          <p className="text-lg text-gray-700 leading-relaxed mb-4">
            في مكتبة توازن، نحترم خصوصيتكم ونلتزم بحماية المعلومات الشخصية التي تشاركونها معنا. هذه السياسة توضح كيفية جمع واستخدام وحماية بياناتكم.
          </p>
          <p className="text-gray-600">
            آخر تحديث: يناير 2024
          </p>
        </div>

        {/* Data Collection */}
        <div className="card p-8 mb-8">
          <div className="flex items-center space-x-4 mb-6">
            <div className="bg-green-100 p-3 rounded-lg">
              <Database className="h-8 w-8 text-green-600" />
            </div>
            <h3 className="text-2xl font-bold text-gray-800">البيانات التي نجمعها</h3>
          </div>
          <div className="space-y-6">
            <div>
              <h4 className="text-lg font-semibold text-gray-800 mb-3">المعلومات الشخصية</h4>
              <ul className="space-y-2 text-gray-700">
                <li>• الاسم الكامل</li>
                <li>• عنوان البريد الإلكتروني</li>
                <li>• رقم الهاتف</li>
                <li>• عنوان الشحن</li>
                <li>• معلومات الدفع (مشفرة وآمنة)</li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold text-gray-800 mb-3">معلومات الاستخدام</h4>
              <ul className="space-y-2 text-gray-700">
                <li>• عنوان IP</li>
                <li>• نوع المتصفح والجهاز</li>
                <li>• صفحات الموقع التي تزورونها</li>
                <li>• وقت ومدة الزيارة</li>
                <li>• مصدر الزيارة (محرك البحث، رابط مباشر، إلخ)</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Data Usage */}
        <div className="card p-8 mb-8">
          <div className="flex items-center space-x-4 mb-6">
            <div className="bg-yellow-100 p-3 rounded-lg">
              <Eye className="h-8 w-8 text-yellow-600" />
            </div>
            <h3 className="text-2xl font-bold text-gray-800">كيف نستخدم بياناتكم</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="text-lg font-semibold text-green-600 mb-3">الاستخدامات الأساسية</h4>
              <ul className="space-y-2 text-gray-700">
                <li>• معالجة وتنفيذ الطلبات</li>
                <li>• التواصل معكم حول طلباتكم</li>
                <li>• تقديم خدمة العملاء</li>
                <li>• إرسال تأكيدات الطلبات</li>
                <li>• معالجة المدفوعات</li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold text-blue-600 mb-3">التحسينات والتطوير</h4>
              <ul className="space-y-2 text-gray-700">
                <li>• تحسين تجربة المستخدم</li>
                <li>• تطوير منتجات جديدة</li>
                <li>• تحليل سلوك المستخدمين</li>
                <li>• إرسال عروض مخصصة (بموافقتكم)</li>
                <li>• تحسين أمان الموقع</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Data Protection */}
        <div className="card p-8 mb-8">
          <div className="flex items-center space-x-4 mb-6">
            <div className="bg-red-100 p-3 rounded-lg">
              <Shield className="h-8 w-8 text-red-600" />
            </div>
            <h3 className="text-2xl font-bold text-gray-800">حماية البيانات</h3>
          </div>
          <div className="space-y-6">
            <div>
              <h4 className="text-lg font-semibold text-gray-800 mb-3">التدابير الأمنية</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h5 className="font-semibold text-blue-800 mb-2">التشفير</h5>
                  <p className="text-sm text-blue-700">جميع البيانات الحساسة مشفرة باستخدام SSL 256-bit</p>
                </div>
                <div className="bg-green-50 p-4 rounded-lg">
                  <h5 className="font-semibold text-green-800 mb-2">الخوادم الآمنة</h5>
                  <p className="text-sm text-green-700">خوادم محمية بجدران حماية متقدمة</p>
                </div>
                <div className="bg-yellow-50 p-4 rounded-lg">
                  <h5 className="font-semibold text-yellow-800 mb-2">الوصول المحدود</h5>
                  <p className="text-sm text-yellow-700">وصول محدود للموظفين المخولين فقط</p>
                </div>
                <div className="bg-purple-50 p-4 rounded-lg">
                  <h5 className="font-semibold text-purple-800 mb-2">النسخ الاحتياطي</h5>
                  <p className="text-sm text-purple-700">نسخ احتياطية منتظمة وآمنة</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Data Sharing */}
        <div className="card p-8 mb-8">
          <h3 className="text-2xl font-bold text-gray-800 mb-6">مشاركة البيانات</h3>
          <div className="space-y-4 text-gray-700">
            <div className="bg-red-50 border border-red-200 p-4 rounded-lg">
              <h4 className="text-lg font-semibold text-red-800 mb-2">لا نبيع بياناتكم</h4>
              <p className="text-red-700">نحن لا نبيع أو نؤجر أو نتاجر ببياناتكم الشخصية لأطراف ثالثة.</p>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold text-gray-800 mb-3">المشاركة المحدودة</h4>
              <p className="mb-2">قد نشارك بياناتكم فقط في الحالات التالية:</p>
              <ul className="space-y-2">
                <li>• مع شركات الشحن لتوصيل طلباتكم</li>
                <li>• مع معالجات الدفع لتنفيذ المعاملات</li>
                <li>• عند الطلب القانوني من السلطات المختصة</li>
                <li>• مع موافقتكم الصريحة</li>
              </ul>
            </div>
          </div>
        </div>

        {/* User Rights */}
        <div className="card p-8 mb-8">
          <h3 className="text-2xl font-bold text-gray-800 mb-6">حقوقكم</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-3">
              <h4 className="text-lg font-semibold text-gray-800">حقوق الوصول والتحكم</h4>
              <ul className="space-y-2 text-gray-700">
                <li>• الوصول إلى بياناتكم الشخصية</li>
                <li>• تصحيح البيانات غير الصحيحة</li>
                <li>• حذف بياناتكم (الحق في النسيان)</li>
                <li>• تقييد معالجة البيانات</li>
              </ul>
            </div>
            <div className="space-y-3">
              <h4 className="text-lg font-semibold text-gray-800">حقوق الاتصال</h4>
              <ul className="space-y-2 text-gray-700">
                <li>• إلغاء الاشتراك في النشرات</li>
                <li>• تغيير تفضيلات التواصل</li>
                <li>• طلب نسخة من بياناتكم</li>
                <li>• تقديم شكوى حول الخصوصية</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Cookies */}
        <div className="card p-8 mb-8">
          <h3 className="text-2xl font-bold text-gray-800 mb-6">ملفات تعريف الارتباط (Cookies)</h3>
          <div className="space-y-4 text-gray-700">
            <p>
              نستخدم ملفات تعريف الارتباط لتحسين تجربتكم على الموقع. هذه الملفات تساعدنا في:
            </p>
            <ul className="space-y-2">
              <li>• تذكر تفضيلاتكم وإعداداتكم</li>
              <li>• تحليل استخدام الموقع</li>
              <li>• تخصيص المحتوى والإعلانات</li>
              <li>• تحسين أداء الموقع</li>
            </ul>
            <p className="text-sm bg-gray-100 p-3 rounded-lg">
              يمكنكم التحكم في ملفات تعريف الارتباط من خلال إعدادات متصفحكم.
            </p>
          </div>
        </div>

        {/* Contact */}
        <div className="card p-8">
          <h3 className="text-2xl font-bold text-gray-800 mb-6">التواصل حول الخصوصية</h3>
          <p className="text-gray-700 mb-4">
            إذا كان لديكم أي أسئلة أو مخاوف حول سياسة الخصوصية أو معالجة بياناتكم، يرجى التواصل معنا:
          </p>
          <div className="space-y-2 text-gray-700">
            <a href="tel:+905516749445" className="block hover:text-blue-600">
              📞 الهاتف: +90 551 674 9445
            </a>
            <a href="mailto:info@tawazonstore.com" className="block hover:text-blue-600">
              📧 البريد الإلكتروني: info@tawazonstore.com
            </a>
            <p>📍 العنوان: فاتح، إسطنبول، تركيا</p>
          </div>
          <div className="mt-6 bg-blue-50 border border-blue-200 p-4 rounded-lg">
            <p className="text-blue-800 font-semibold">
              نلتزم بالرد على جميع استفساراتكم حول الخصوصية خلال 48 ساعة.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PrivacyPolicy;