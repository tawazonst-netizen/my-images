import React from 'react';
import { MapPin, Phone, Mail, MessageCircle, Send, Clock } from 'lucide-react';

const Contact = () => {
  return (
    <div className="py-8">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-50 to-green-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl font-bold text-gray-800 mb-6">تواصل معنا</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            نحن هنا لمساعدتك في اختيار أفضل المواد التعليمية لطفلك
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          {/* Contact Information */}
          <div className="space-y-8">
            <div>
              <h2 className="text-3xl font-bold text-gray-800 mb-6">معلومات التواصل</h2>
              <p className="text-lg text-gray-600 mb-8">
                تواصل معنا عبر إحدى الطرق التالية، فريقنا جاهز لمساعدتك
              </p>
            </div>

            {/* Contact Methods */}
            <div className="space-y-6">
              <div className="flex items-start space-x-4 p-4 bg-white rounded-xl shadow-md hover:shadow-lg transition-shadow">
                <div className="bg-blue-100 p-3 rounded-lg">
                  <MapPin className="h-6 w-6 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-bold text-gray-800 mb-2">العنوان</h3>
                  <p className="text-gray-600">فاتح، إسطنبول، تركيا</p>
                  <p className="text-sm text-gray-500">شارع الكتب التفاعلية، مجمع توازن التعليمي</p>
                </div>
              </div>

              <div className="flex items-start space-x-4 p-4 bg-white rounded-xl shadow-md hover:shadow-lg transition-shadow">
                <div className="bg-green-100 p-3 rounded-lg">
                  <Phone className="h-6 w-6 text-green-600" />
                </div>
                <div>
                  <h3 className="font-bold text-gray-800 mb-2">الهاتف</h3>
                  <a href="tel:+905516749445" className="text-gray-600 hover:text-blue-600 transition-colors">
                    +90 551 674 9445
                  </a>
                  <p className="text-sm text-gray-500">متاح يومياً من 9 صباحاً إلى 6 مساءً</p>
                </div>
              </div>

              <div className="flex items-start space-x-4 p-4 bg-white rounded-xl shadow-md hover:shadow-lg transition-shadow">
                <div className="bg-yellow-100 p-3 rounded-lg">
                  <Mail className="h-6 w-6 text-yellow-600" />
                </div>
                <div>
                  <h3 className="font-bold text-gray-800 mb-2">البريد الإلكتروني</h3>
                  <a href="mailto:info@tawazonstore.com" className="text-gray-600 hover:text-blue-600 transition-colors">
                    info@tawazonstore.com
                  </a>
                  <p className="text-sm text-gray-500">سنرد خلال 24 ساعة</p>
                </div>
              </div>
            </div>

            {/* Direct Contact Buttons */}
            <div className="space-y-4">
              <h3 className="text-xl font-bold text-gray-800">تواصل مباشر</h3>
              <div className="flex gap-4">
                <a 
                  href="https://wa.me/905516749445?text=مرحباً%20أرغب%20بالاستفسار%20عن%20منتجاتكم"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-green-500 hover:bg-green-600 text-white font-semibold py-4 px-6 rounded-xl transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl flex items-center space-x-3 flex-1 justify-center"
                >
                  <MessageCircle className="h-6 w-6" />
                  <span>واتساب</span>
                </a>
              </div>
            </div>

            {/* Working Hours */}
            <div className="bg-gray-100 p-6 rounded-xl">
              <div className="flex items-center space-x-3 mb-4">
                <Clock className="h-6 w-6 text-gray-600" />
                <h3 className="text-xl font-bold text-gray-800">ساعات العمل</h3>
              </div>
              <div className="space-y-2 text-gray-700">
                <div className="flex justify-between">
                  <span>السبت - الخميس</span>
                  <span>9:00 ص - 6:00 م</span>
                </div>
                <div className="flex justify-between">
                  <span>الجمعة</span>
                  <span>مغلق</span>
                </div>
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <div className="card p-8">
            <h2 className="text-3xl font-bold text-gray-800 mb-6">أرسل لنا رسالة</h2>
            <form className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    الاسم *
                  </label>
                  <input
                    type="text"
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                    placeholder="اسمك الكامل"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    رقم الهاتف
                  </label>
                  <input
                    type="tel"
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                    placeholder="+966 5X XXX XXXX"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  البريد الإلكتروني *
                </label>
                <input
                  type="email"
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                  placeholder="your-email@example.com"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  الموضوع
                </label>
                <select className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors">
                  <option>استفسار عام</option>
                  <option>سؤال حول منتج</option>
                  <option>طلب اقتراح</option>
                  <option>شكوى أو مقترح</option>
                  <option>طلب دعم تقني</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  الرسالة *
                </label>
                <textarea
                  rows={6}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors resize-none"
                  placeholder="اكتب رسالتك هنا..."
                ></textarea>
              </div>

              <button type="submit" className="w-full btn-primary">
                إرسال الرسالة
              </button>
            </form>
          </div>
        </div>

        {/* Map Section */}
        <div className="mt-16">
          <div className="card p-8">
            <h3 className="text-2xl font-bold text-gray-800 mb-6 text-center">موقعنا</h3>
            <div className="bg-gray-200 rounded-xl h-64 flex items-center justify-center">
              <div className="text-center text-gray-600">
                <MapPin className="h-12 w-12 mx-auto mb-4" />
                <p className="text-lg font-semibold">خريطة تفاعلية</p>
                <p>فاتح، إسطنبول، تركيا</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;