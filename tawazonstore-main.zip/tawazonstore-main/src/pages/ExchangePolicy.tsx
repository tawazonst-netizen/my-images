import React from 'react';
import { RefreshCw, Clock, CheckCircle, XCircle } from 'lucide-react';

const ExchangePolicy = () => {
  return (
    <div className="py-8">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-50 to-green-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl font-bold text-gray-800 mb-6">سياسة الاستبدال</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            نحن ملتزمون بضمان رضاكم الكامل عن منتجاتنا
          </p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Overview */}
        <div className="card p-8 mb-8">
          <div className="flex items-center space-x-4 mb-6">
            <div className="bg-blue-100 p-3 rounded-lg">
              <RefreshCw className="h-8 w-8 text-blue-600" />
            </div>
            <h2 className="text-3xl font-bold text-gray-800">نظرة عامة</h2>
          </div>
          <p className="text-lg text-gray-700 leading-relaxed">
            في مكتبة توازن، نؤمن بجودة منتجاتنا ونسعى لضمان رضاكم الكامل. لذلك نوفر سياسة استبدال مرنة وعادلة تحمي حقوقكم كعملاء وتضمن حصولكم على أفضل تجربة تسوق.
          </p>
        </div>

        {/* Exchange Conditions */}
        <div className="card p-8 mb-8">
          <h3 className="text-2xl font-bold text-gray-800 mb-6">شروط الاستبدال</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h4 className="text-lg font-semibold text-green-600 flex items-center space-x-2">
                <CheckCircle className="h-5 w-5" />
                <span>يمكن استبدالها</span>
              </h4>
              <ul className="space-y-2 text-gray-700">
                <li>• المنتجات في حالتها الأصلية</li>
                <li>• المنتجات غير المستعملة</li>
                <li>• المنتجات مع العبوة الأصلية</li>
                <li>• المنتجات خلال 14 يوم من الاستلام</li>
                <li>• المنتجات مع الفاتورة الأصلية</li>
              </ul>
            </div>
            <div className="space-y-4">
              <h4 className="text-lg font-semibold text-red-600 flex items-center space-x-2">
                <XCircle className="h-5 w-5" />
                <span>لا يمكن استبدالها</span>
              </h4>
              <ul className="space-y-2 text-gray-700">
                <li>• المنتجات المستعملة أو التالفة</li>
                <li>• المنتجات بدون العبوة الأصلية</li>
                <li>• المنتجات المخصصة أو المطبوعة حسب الطلب</li>
                <li>• المنتجات بعد انتهاء فترة الاستبدال</li>
                <li>• المنتجات المعروضة بخصم أكثر من 50%</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Time Limits */}
        <div className="card p-8 mb-8">
          <div className="flex items-center space-x-4 mb-6">
            <div className="bg-yellow-100 p-3 rounded-lg">
              <Clock className="h-8 w-8 text-yellow-600" />
            </div>
            <h3 className="text-2xl font-bold text-gray-800">المدد الزمنية</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center p-6 bg-blue-50 rounded-xl">
              <h4 className="text-3xl font-bold text-blue-600 mb-2">14</h4>
              <p className="text-gray-700">يوم لطلب الاستبدال</p>
            </div>
            <div className="text-center p-6 bg-green-50 rounded-xl">
              <h4 className="text-3xl font-bold text-green-600 mb-2">3-5</h4>
              <p className="text-gray-700">أيام لمعالجة الطلب</p>
            </div>
            <div className="text-center p-6 bg-yellow-50 rounded-xl">
              <h4 className="text-3xl font-bold text-yellow-600 mb-2">7-10</h4>
              <p className="text-gray-700">أيام لاستلام البديل</p>
            </div>
          </div>
        </div>

        {/* Exchange Process */}
        <div className="card p-8 mb-8">
          <h3 className="text-2xl font-bold text-gray-800 mb-6">خطوات الاستبدال</h3>
          <div className="space-y-6">
            {[
              {
                step: '1',
                title: 'تواصل معنا',
                description: 'اتصل بخدمة العملاء أو أرسل بريد إلكتروني مع رقم الطلب وسبب الاستبدال'
              },
              {
                step: '2',
                title: 'تأكيد الطلب',
                description: 'سنراجع طلبك ونؤكد إمكانية الاستبدال خلال 24 ساعة'
              },
              {
                step: '3',
                title: 'إرسال المنتج',
                description: 'أرسل المنتج في عبوته الأصلية إلى العنوان المحدد'
              },
              {
                step: '4',
                title: 'الفحص والمعالجة',
                description: 'سنفحص المنتج ونعالج طلب الاستبدال خلال 3-5 أيام عمل'
              },
              {
                step: '5',
                title: 'إرسال البديل',
                description: 'سنرسل المنتج البديل أو نرد المبلغ حسب اختيارك'
              }
            ].map((item, index) => (
              <div key={index} className="flex items-start space-x-4">
                <div className="bg-blue-500 text-white w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm">
                  {item.step}
                </div>
                <div>
                  <h4 className="text-lg font-semibold text-gray-800 mb-2">{item.title}</h4>
                  <p className="text-gray-700">{item.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Contact Info */}
        <div className="card p-8">
          <h3 className="text-2xl font-bold text-gray-800 mb-6">تواصل معنا للاستبدال</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold text-gray-800 mb-3">معلومات التواصل</h4>
              <div className="space-y-2 text-gray-700">
                <a href="tel:+905516749445" className="flex items-center hover:text-blue-600">
                  📞 الهاتف: +90 551 674 9445
                </a>
                <a href="mailto:info@tawazonstore.com" className="flex items-center hover:text-blue-600">
                  📧 البريد الإلكتروني: info@tawazonstore.com
                </a>
                <a href="https://wa.me/905516749445?text=أرغب%20بالاستفسار%20عن%20سياسة%20الاستبدال" 
                   target="_blank" rel="noopener noreferrer" className="flex items-center hover:text-blue-600">
                  💬 واتساب: متاح 24/7
                </a>
                <p>⏰ ساعات العمل: السبت - الخميس، 9 ص - 6 م</p>
              </div>
            </div>
            <div>
              <h4 className="font-semibold text-gray-800 mb-3">عنوان الإرسال</h4>
              <div className="text-gray-700">
                <p>مكتبة توازن</p>
                <p>فاتح، إسطنبول</p>
                <p>تركيا</p>
                <p className="text-sm text-gray-600 mt-2">
                  * يرجى عدم إرسال أي منتج بدون تأكيد مسبق من فريق خدمة العملاء
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ExchangePolicy;