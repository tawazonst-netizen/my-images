import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Calendar, User, Clock, ArrowLeft, Share2, Heart } from 'lucide-react';

const BlogPost = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  // Mock blog posts data - in real app, this would come from API
  const posts = [
    {
      id: 1,
      title: 'كيفية تعليم القراءة المبكرة للأطفال',
      titleEn: 'How to Teach Early Reading to Children',
      excerpt: 'دليل شامل للأهالي حول أفضل الطرق لتعليم القراءة للأطفال في سن مبكرة...',
      content: `
        <p>تعليم القراءة المبكرة للأطفال هو من أهم الاستثمارات التي يمكن للوالدين القيام بها في مستقبل أطفالهم. في هذا المقال، سنستكشف أفضل الطرق والاستراتيجيات لتعليم الأطفال القراءة في سن مبكرة.</p>

        <h2>أهمية القراءة المبكرة</h2>
        <p>القراءة المبكرة تساعد في تطوير المهارات اللغوية والمعرفية للطفل. الأطفال الذين يتعلمون القراءة مبكراً يظهرون تفوقاً أكاديمياً أفضل في المراحل التعليمية اللاحقة.</p>

        <h2>الخطوات الأساسية لتعليم القراءة</h2>
        <h3>1. البدء بالحروف</h3>
        <p>ابدأ بتعليم الطفل الحروف الأبجدية وأصواتها. استخدم الألعاب والأنشطة التفاعلية لجعل التعلم ممتعاً.</p>

        <h3>2. تكوين الكلمات البسيطة</h3>
        <p>بعد إتقان الحروف، انتقل إلى تكوين كلمات بسيطة من حرفين أو ثلاثة أحرف.</p>

        <h3>3. القراءة التفاعلية</h3>
        <p>اقرأ مع طفلك يومياً واجعله يشارك في القراءة تدريجياً.</p>

        <h2>نصائح للنجاح</h2>
        <ul>
          <li>اجعل وقت القراءة ممتعاً وليس إجبارياً</li>
          <li>استخدم الكتب المصورة والملونة</li>
          <li>كافئ الطفل على تقدمه</li>
          <li>كن صبوراً ومتفهماً</li>
          <li>اربط القراءة بالأنشطة اليومية</li>
        </ul>

        <h2>الأدوات المساعدة</h2>
        <p>استخدم الكتب التفاعلية، الألعاب التعليمية، والتطبيقات المناسبة لعمر الطفل. مكتبة توازن توفر مجموعة واسعة من هذه الأدوات.</p>

        <h2>الخلاصة</h2>
        <p>تعليم القراءة المبكرة يتطلب صبراً واستمرارية، لكن النتائج تستحق الجهد المبذول. ابدأ مبكراً واجعل التعلم تجربة ممتعة لك ولطفلك.</p>
      `,
      image: 'https://images.pexels.com/photos/4491461/pexels-photo-4491461.jpeg?auto=compress&cs=tinysrgb&w=800',
      author: 'د. فاطمة الزهراني',
      date: '2024-01-15',
      readTime: '5 دقائق',
      category: 'نصائح للأهالي',
      tags: ['تعليم', 'قراءة', 'أطفال', 'تربية']
    },
    {
      id: 2,
      title: 'أهمية الكتب التفاعلية في التعليم',
      titleEn: 'The Importance of Interactive Books in Education',
      excerpt: 'تعرف على فوائد الكتب التفاعلية وكيف تساعد في تطوير مهارات الطفل المعرفية...',
      content: `
        <p>الكتب التفاعلية ثورة حقيقية في عالم التعليم المبكر. تجمع هذه الكتب بين المتعة والتعلم بطريقة لا تضاهى.</p>

        <h2>ما هي الكتب التفاعلية؟</h2>
        <p>الكتب التفاعلية هي كتب تحتوي على عناصر تفاعلية مثل الأصوات، الأضواء، الملمس المختلف، والأجزاء المتحركة.</p>

        <h2>فوائد الكتب التفاعلية</h2>
        <ul>
          <li>تحفز حواس الطفل المختلفة</li>
          <li>تزيد من مدة انتباه الطفل</li>
          <li>تجعل التعلم أكثر متعة</li>
          <li>تطور المهارات الحركية الدقيقة</li>
        </ul>
      `,
      image: 'https://images.pexels.com/photos/5428836/pexels-photo-5428836.jpeg?auto=compress&cs=tinysrgb&w=800',
      author: 'أ. أحمد الشامي',
      date: '2024-01-10',
      readTime: '7 دقائق',
      category: 'التعليم التفاعلي',
      tags: ['كتب تفاعلية', 'تعليم', 'تطوير']
    },
    {
      id: 3,
      title: 'دور اللعب في التعلم المبكر',
      titleEn: 'The Role of Play in Early Learning',
      excerpt: 'كيف يمكن للعب أن يكون أداة تعليمية قوية ويساعد في تنمية مهارات الطفل...',
      content: `
        <p>اللعب ليس مجرد وسيلة ترفيه للأطفال، بل هو أداة تعليمية قوية تساعد في تطوير مختلف جوانب شخصية الطفل.</p>

        <h2>أنواع اللعب التعليمي</h2>
        <p>هناك أنواع مختلفة من الألعاب التعليمية التي تخدم أهدافاً تعليمية متنوعة.</p>
      `,
      image: 'https://images.pexels.com/photos/8613089/pexels-photo-8613089.jpeg?auto=compress&cs=tinysrgb&w=800',
      author: 'أ. نورا العلي',
      date: '2024-01-08',
      readTime: '6 دقائق',
      category: 'التعلم باللعب',
      tags: ['لعب', 'تعليم', 'تطوير']
    }
  ];

  const post = posts.find(p => p.id === parseInt(id || '1')) || posts[0];
  const relatedPosts = posts.filter(p => p.id !== post.id).slice(0, 3);

  return (
    <div className="py-8">
      {/* Breadcrumb */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 mb-8">
        <div className="flex items-center space-x-2 text-sm text-gray-600">
          <button onClick={() => navigate('/')} className="hover:text-blue-600">الرئيسية</button>
          <span>/</span>
          <button onClick={() => navigate('/blog')} className="hover:text-blue-600">المحتوى التعليمي</button>
          <span>/</span>
          <span className="text-gray-800">{post.title}</span>
        </div>
      </div>

      <article className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Article Header */}
        <header className="mb-8">
          <div className="mb-4">
            <span className="bg-blue-100 text-blue-600 px-3 py-1 rounded-full text-sm font-medium">
              {post.category}
            </span>
          </div>
          
          <h1 className="text-4xl font-bold text-gray-800 mb-4 leading-tight">
            {post.title}
          </h1>
          
          <div className="flex items-center space-x-6 text-gray-600 mb-6">
            <div className="flex items-center space-x-2">
              <User className="h-4 w-4" />
              <span>{post.author}</span>
            </div>
            <div className="flex items-center space-x-2">
              <Calendar className="h-4 w-4" />
              <span>{post.date}</span>
            </div>
            <div className="flex items-center space-x-2">
              <Clock className="h-4 w-4" />
              <span>{post.readTime}</span>
            </div>
          </div>

          <div className="flex items-center space-x-4 mb-8">
            <button className="flex items-center space-x-2 bg-blue-100 text-blue-600 px-4 py-2 rounded-lg hover:bg-blue-200 transition-colors">
              <Share2 className="h-4 w-4" />
              <span>مشاركة</span>
            </button>
            <button className="flex items-center space-x-2 bg-red-100 text-red-600 px-4 py-2 rounded-lg hover:bg-red-200 transition-colors">
              <Heart className="h-4 w-4" />
              <span>إعجاب</span>
            </button>
          </div>

          <img
            src={post.image}
            alt={post.title}
            className="w-full h-64 md:h-96 object-cover rounded-2xl shadow-lg mb-8"
          />
        </header>

        {/* Article Content */}
        <div className="prose prose-lg max-w-none mb-12">
          <div 
            dangerouslySetInnerHTML={{ __html: post.content }}
            className="text-gray-700 leading-relaxed"
          />
        </div>

        {/* Tags */}
        <div className="mb-8">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">الكلمات المفتاحية</h3>
          <div className="flex flex-wrap gap-2">
            {post.tags.map((tag, index) => (
              <span
                key={index}
                className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm hover:bg-gray-200 cursor-pointer"
              >
                #{tag}
              </span>
            ))}
          </div>
        </div>

        {/* Author Bio */}
        <div className="card p-6 mb-12">
          <div className="flex items-center space-x-4">
            <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center">
              <User className="h-8 w-8 text-blue-600" />
            </div>
            <div>
              <h4 className="text-xl font-bold text-gray-800">{post.author}</h4>
              <p className="text-gray-600">
                خبير في التعليم المبكر ومؤلف عدة كتب في مجال تربية الأطفال
              </p>
            </div>
          </div>
        </div>

        {/* Related Articles */}
        <div className="mb-12">
          <h3 className="text-2xl font-bold text-gray-800 mb-8">مقالات ذات صلة</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {relatedPosts.map((relatedPost) => (
              <article key={relatedPost.id} className="card p-6 group cursor-pointer"
                onClick={() => navigate(`/blog/${relatedPost.id}`)}>
                <img
                  src={relatedPost.image}
                  alt={relatedPost.title}
                  className="w-full h-48 object-cover rounded-xl mb-4"
                />
                <div className="mb-2">
                  <span className="bg-blue-100 text-blue-600 px-2 py-1 rounded-full text-xs font-medium">
                    {relatedPost.category}
                  </span>
                </div>
                <h4 className="text-lg font-bold text-gray-800 mb-2 group-hover:text-blue-600 transition-colors">
                  {relatedPost.title}
                </h4>
                <p className="text-gray-600 text-sm mb-4">{relatedPost.excerpt}</p>
                <div className="flex items-center text-xs text-gray-500">
                  <span>{relatedPost.author}</span>
                  <span className="mx-2">•</span>
                  <span>{relatedPost.readTime}</span>
                </div>
              </article>
            ))}
          </div>
        </div>

        {/* Back to Blog */}
        <div className="text-center">
          <button
            onClick={() => navigate('/blog')}
            className="btn-primary flex items-center space-x-2 mx-auto"
          >
            <ArrowLeft className="h-5 w-5" />
            <span>العودة للمحتوى التعليمي</span>
          </button>
        </div>
      </article>
    </div>
  );
};

export default BlogPost;