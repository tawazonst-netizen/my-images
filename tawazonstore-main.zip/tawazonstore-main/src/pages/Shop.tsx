import React, { useState } from 'react';
import { Filter, Grid, List, ShoppingCart, Heart, Star, Eye } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import { useCurrency } from '../context/CurrencyContext';
import QuickView from '../components/QuickView';
import LoginModal from '../components/LoginModal';

const Shop = () => {
  const { dispatch } = useCart();
  const { state: authState, addToFavorites, removeFromFavorites } = useAuth();
  const { formatPrice } = useCurrency();
  const navigate = useNavigate();
  const [viewMode, setViewMode] = useState('grid');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [quickViewProduct, setQuickViewProduct] = useState<any>(null);
  const [isQuickViewOpen, setIsQuickViewOpen] = useState(false);
  const [showLoginModal, setShowLoginModal] = useState(false);

  const categories = [
    { id: 'all', name: 'جميع المنتجات', nameEn: 'All Products' },
    { id: 'first-books', name: 'سلسلة كتابي الأول', nameEn: 'My First Book Series' },
    { id: 'lets-learn', name: 'سلسلة هيا نتعلم', nameEn: 'Let\'s Learn Series' },
    { id: 'games', name: 'الألعاب التعليمية', nameEn: 'Educational Games' },
    { id: 'tools', name: 'أدوات الدعم', nameEn: 'Support Tools' }
  ];

  const products = [
    {
      id: 1,
      title: 'كتابي الأول في التعرف على الألوان',
      priceUSD: 15,
      image: 'https://images.pexels.com/photos/4473775/pexels-photo-4473775.jpeg?auto=compress&cs=tinysrgb&w=600',
      rating: 4.9,
      reviews: 89,
      category: 'first-books',
      ageRange: '2-4 سنوات', 
      weight: 0.8,
      description: 'كتاب تفاعلي لتعليم الألوان بطريقة ممتعة'
    },
    {
      id: 2,
      title: 'لعبة الأرقام السحرية',
      priceUSD: 25,
      image: 'https://images.pexels.com/photos/8613089/pexels-photo-8613089.jpeg?auto=compress&cs=tinysrgb&w=600',
      rating: 4.8,
      reviews: 134,
      category: 'games',
      ageRange: '3-6 سنوات',
      weight: 1.2,
      description: 'لعبة تعليمية لتعلم الأرقام والعد'
    },
    {
      id: 3,
      title: 'مجموعة القراءة التفاعلية',
      priceUSD: 35,
      image: 'https://images.pexels.com/photos/5428836/pexels-photo-5428836.jpeg?auto=compress&cs=tinysrgb&w=600',
      rating: 5.0,
      reviews: 203,
      category: 'lets-learn',
      ageRange: '4-8 سنوات',
      weight: 1.5,
      description: 'مجموعة شاملة لتطوير مهارات القراءة'
    },
    {
      id: 4,
      title: 'دليل المعلم الذكي',
      priceUSD: 30,
      image: 'https://images.pexels.com/photos/8923059/pexels-photo-8923059.jpeg?auto=compress&cs=tinysrgb&w=600',
      rating: 4.7,
      reviews: 56,
      category: 'tools',
      ageRange: 'للمعلمين',
      weight: 0.9,
      description: 'أدوات ونصائح للمعلمين والمربين'
    },
    {
      id: 5,
      title: 'كتابي الأول في التعرف على الأشكال',
      priceUSD: 18,
      image: 'https://images.pexels.com/photos/4473409/pexels-photo-4473409.jpeg?auto=compress&cs=tinysrgb&w=600',
      rating: 4.6,
      reviews: 78,
      category: 'first-books',
      ageRange: '2-4 سنوات',
      weight: 0.7,
      description: 'تعليم الأشكال الهندسية الأساسية'
    },
    {
      id: 6,
      title: 'لوحة الكتابة الذكية',
      priceUSD: 40,
      image: 'https://images.pexels.com/photos/4491461/pexels-photo-4491461.jpeg?auto=compress&cs=tinysrgb&w=600',
      rating: 4.9,
      reviews: 167,
      category: 'games',
      ageRange: '5-8 سنوات',
      weight: 2.0,
      description: 'لوحة تفاعلية لتعلم الكتابة'
    }
  ];

  const filteredProducts = selectedCategory === 'all' 
    ? products 
    : products.filter(product => product.category === selectedCategory);

  const addToCart = (product: typeof products[0]) => {
    dispatch({
      type: 'ADD_ITEM',
      payload: {
        id: product.id,
        title: product.title,
          price: product.priceUSD,
          originalPrice: product.priceUSD * 1.2,
        image: product.image,
        ageRange: product.ageRange
      }
    });
  };

  const handleFavoriteToggle = (product: any) => {
    if (!authState.isAuthenticated) {
      setShowLoginModal(true);
      return;
    }

    const isFavorite = authState.user?.favorites.includes(product.id);
    if (isFavorite) {
      removeFromFavorites(product.id);
    } else {
      addToFavorites(product.id);
    }
  };

  const openQuickView = (product: any) => {
    setQuickViewProduct(product);
    setIsQuickViewOpen(true);
  };

  const closeQuickView = () => {
    setQuickViewProduct(null);
    setIsQuickViewOpen(false);
  };

  return (
    <div className="py-8">
      {/* Header */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-8">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-800 mb-4">متجر توازن</h1>
          <p className="text-xl text-gray-600">اكتشف مجموعتنا الواسعة من المواد التعليمية</p>
        </div>

        {/* Filters and View Controls */}
        <div className="flex flex-col md:flex-row justify-between items-center gap-4 mb-8">
          {/* Categories */}
          <div className="flex flex-wrap gap-2">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={`px-4 py-2 rounded-lg font-medium transition-all duration-200 ${
                  selectedCategory === category.id
                    ? 'bg-blue-500 text-white'
                    : 'bg-white text-gray-700 hover:bg-gray-100'
                }`}
              >
                {category.name}
              </button>
            ))}
          </div>

          {/* View Mode */}
          <div className="flex items-center space-x-2 bg-white rounded-lg p-1">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-2 rounded-md transition-colors ${
                viewMode === 'grid' ? 'bg-blue-100 text-blue-600' : 'text-gray-600'
              }`}
            >
              <Grid className="h-5 w-5" />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-2 rounded-md transition-colors ${
                viewMode === 'list' ? 'bg-blue-100 text-blue-600' : 'text-gray-600'
              }`}
            >
              <List className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Products */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className={`grid gap-8 ${
          viewMode === 'grid' 
            ? 'grid-cols-1 md:grid-cols-2 xl:grid-cols-3' 
            : 'grid-cols-1'
        }`}>
          {filteredProducts.map((product) => (
            <div key={product.id} className={`card p-6 group ${
              viewMode === 'list' ? 'flex flex-col md:flex-row gap-6' : ''
            }`}>
              {/* Product Image */}
              <div className={`relative ${viewMode === 'list' ? 'md:w-64 flex-shrink-0' : ''}`}>
                <img
                  src={product.image}
                  alt={product.title}
                  className={`w-full object-cover rounded-xl ${
                    viewMode === 'list' ? 'h-48 md:h-full' : 'h-48'
                  }`}
                />
                <button 
                  onClick={() => handleFavoriteToggle(product)}
                  className={`absolute top-3 right-3 p-2 rounded-full shadow-lg opacity-0 group-hover:opacity-100 transition-all duration-300 ${
                    authState.user?.favorites.includes(product.id)
                      ? 'bg-red-100 text-red-500'
                      : 'bg-white text-gray-600 hover:bg-red-50 hover:text-red-500'
                  }`}
                >
                  <Heart className={`h-5 w-5 ${authState.user?.favorites.includes(product.id) ? 'fill-current' : ''}`} />
                </button>
              </div>

              {/* Product Info */}
              <div className={`space-y-4 ${viewMode === 'list' ? 'flex-1' : ''}`}>
                <div>
                  <h3 className="text-xl font-bold text-gray-800 mb-2">{product.title}</h3>
                  <p className="text-gray-600 mb-2">{product.description}</p>
                  <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm font-medium">
                    {product.ageRange}
                  </span>
                </div>

                {/* Rating */}
                <div className="flex items-center space-x-2">
                  <div className="flex text-yellow-400">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`h-4 w-4 ${i < Math.floor(product.rating) ? 'fill-current' : ''}`}
                      />
                    ))}
                  </div>
                  <span className="text-sm text-gray-600">({product.reviews})</span>
                </div>

                {/* Price */}
                <div className="flex items-center space-x-3">
                  <span className="text-2xl font-bold text-blue-600">{formatPrice(product.priceUSD)}</span>
                  <span className="text-sm text-gray-500">الوزن: {product.weight} كيلو</span>
                </div>

                {/* Actions */}
                <div className="flex gap-3">
                  <button 
                    onClick={() => addToCart(product)}
                    className="btn-primary flex-1 flex items-center justify-center space-x-2"
                  >
                    <ShoppingCart className="h-5 w-5" />
                    <span>أضف للسلة</span>
                  </button>
                  <button 
                    onClick={() => openQuickView(product)}
                    className="bg-gray-200 hover:bg-gray-300 text-gray-700 px-4 py-3 rounded-xl transition-colors flex items-center space-x-2"
                  >
                    <Eye className="h-4 w-4" />
                    <span>عرض سريع</span>
                  </button>
                </div>

                {/* Payment Options */}
                <div className="text-sm text-gray-600 space-y-1">
                  <p>✓ طلب عبر الواتساب</p>
                  <p>✓ شحن محسوب حسب الوزن والموقع</p>
                  <button 
                    onClick={() => navigate(`/product/${product.id}`)}
                    className="text-blue-600 hover:underline text-sm"
                  >
                    عرض التفاصيل الكاملة
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Quick View Modal */}
      <QuickView
        product={quickViewProduct}
        isOpen={isQuickViewOpen}
        onClose={closeQuickView}
      />

      {/* Login Modal */}
      <LoginModal isOpen={showLoginModal} onClose={() => setShowLoginModal(false)} />
    </div>
  );
};

export default Shop;