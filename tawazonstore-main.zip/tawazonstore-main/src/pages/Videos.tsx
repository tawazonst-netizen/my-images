import React, { useState, useRef, useEffect } from 'react';
import { ChevronUp, ChevronDown, Play, Pause, Volume2, VolumeX, Share2, Heart, MessageCircle, ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const Videos = () => {
  const navigate = useNavigate();
  const [currentVideo, setCurrentVideo] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(true);
  const videoRefs = useRef<(HTMLVideoElement | null)[]>([]);
  const containerRef = useRef<HTMLDivElement>(null);

  const videos = [
    {
      id: 1,
      title: 'كيف تعلمين طفلك القراءة؟',
      titleEn: 'How to Teach Your Child to Read?',
      category: '📚 نصائح للأهالي',
      categoryEn: '📚 Parent Tips',
      thumbnail: 'https://images.pexels.com/photos/4491461/pexels-photo-4491461.jpeg?auto=compress&cs=tinysrgb&w=400',
      videoUrl: 'https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_1mb.mp4',
      description: 'تعلمي أفضل الطرق لتعليم طفلك القراءة بطريقة ممتعة وتفاعلية',
      descriptionEn: 'Learn the best ways to teach your child reading in a fun and interactive way',
      author: 'د. فاطمة الزهراني',
      authorEn: 'Dr. Fatima Al-Zahrani',
      likes: 245,
      comments: 32,
      shares: 18,
      relatedProduct: {
        id: 1,
        title: 'كتاب الحروف المتحركة',
        titleEn: 'Interactive Letters Book'
      },
      captions: {
        ar: 'مرحباً أعزائي الأهالي، اليوم سنتعلم كيفية تعليم الأطفال القراءة بطريقة ممتعة...',
        en: 'Hello dear parents, today we will learn how to teach children reading in a fun way...'
      }
    },
    {
      id: 2,
      title: 'أنشطة ممتعة مع كتب توازن',
      titleEn: 'Fun Activities with Tawazon Books',
      category: '🎲 أنشطة من منتجاتنا',
      categoryEn: '🎲 Product Activities',
      thumbnail: 'https://images.pexels.com/photos/5428836/pexels-photo-5428836.jpeg?auto=compress&cs=tinysrgb&w=400',
      videoUrl: 'https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_2mb.mp4',
      description: 'شاهدي كيف يمكن استخدام كتبنا التفاعلية في أنشطة تعليمية متنوعة',
      descriptionEn: 'See how our interactive books can be used in various educational activities',
      author: 'أ. أحمد الشامي',
      authorEn: 'Mr. Ahmed Al-Shami',
      likes: 189,
      comments: 24,
      shares: 15,
      relatedProduct: {
        id: 2,
        title: 'مجموعة القراءة التفاعلية',
        titleEn: 'Interactive Reading Set'
      },
      captions: {
        ar: 'هذه بعض الأنشطة الرائعة التي يمكنكم القيام بها مع أطفالكم...',
        en: 'Here are some wonderful activities you can do with your children...'
      }
    },
    {
      id: 3,
      title: 'تجربة أم سارة مع ابنتها',
      titleEn: 'Sara\'s Experience with Her Daughter',
      category: '👩‍👦 تجارب الأهالي',
      categoryEn: '👩‍👦 Parent Reviews',
      thumbnail: 'https://images.pexels.com/photos/4474035/pexels-photo-4474035.jpeg?auto=compress&cs=tinysrgb&w=400',
      videoUrl: 'https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_1mb.mp4',
      description: 'استمعي لتجربة الأم سارة وكيف ساعدت كتب توازن في تطوير مهارات ابنتها',
      descriptionEn: 'Listen to Sara\'s experience and how Tawazon books helped develop her daughter\'s skills',
      author: 'سارة أحمد',
      authorEn: 'Sara Ahmed',
      likes: 312,
      comments: 45,
      shares: 28,
      relatedProduct: {
        id: 3,
        title: 'سلسلة كتابي الأول',
        titleEn: 'My First Book Series'
      },
      captions: {
        ar: 'ابنتي كانت تواجه صعوبة في القراءة، لكن مع كتب توازن...',
        en: 'My daughter was struggling with reading, but with Tawazon books...'
      }
    },
    {
      id: 4,
      title: 'ألعاب تعليمية للأطفال',
      titleEn: 'Educational Games for Children',
      category: '🎲 أنشطة من منتجاتنا',
      categoryEn: '🎲 Product Activities',
      thumbnail: 'https://images.pexels.com/photos/8613089/pexels-photo-8613089.jpeg?auto=compress&cs=tinysrgb&w=400',
      videoUrl: 'https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_2mb.mp4',
      description: 'اكتشفي مجموعة الألعاب التعليمية وكيفية استخدامها لتطوير مهارات طفلك',
      descriptionEn: 'Discover our educational games collection and how to use them to develop your child\'s skills',
      author: 'أ. نورا العلي',
      authorEn: 'Ms. Nora Al-Ali',
      likes: 156,
      comments: 19,
      shares: 12,
      relatedProduct: {
        id: 4,
        title: 'لعبة الأرقام السحرية',
        titleEn: 'Magic Numbers Game'
      },
      captions: {
        ar: 'الألعاب التعليمية طريقة رائعة لجعل التعلم ممتعاً...',
        en: 'Educational games are a great way to make learning fun...'
      }
    }
  ];

  const [language, setLanguage] = useState('ar');

  useEffect(() => {
    const handleScroll = (e: WheelEvent) => {
      e.preventDefault();
      if (e.deltaY > 0 && currentVideo < videos.length - 1) {
        setCurrentVideo(prev => prev + 1);
      } else if (e.deltaY < 0 && currentVideo > 0) {
        setCurrentVideo(prev => prev - 1);
      }
    };

    const container = containerRef.current;
    if (container) {
      container.addEventListener('wheel', handleScroll, { passive: false });
      return () => container.removeEventListener('wheel', handleScroll);
    }
  }, [currentVideo, videos.length]);

  useEffect(() => {
    // Pause all videos except current
    videoRefs.current.forEach((video, index) => {
      if (video) {
        if (index === currentVideo && isPlaying) {
          video.play();
        } else {
          video.pause();
        }
      }
    });
  }, [currentVideo, isPlaying]);

  const togglePlay = () => {
    setIsPlaying(!isPlaying);
  };

  const toggleMute = () => {
    setIsMuted(!isMuted);
    const currentVideoElement = videoRefs.current[currentVideo];
    if (currentVideoElement) {
      currentVideoElement.muted = !isMuted;
    }
  };

  const nextVideo = () => {
    if (currentVideo < videos.length - 1) {
      setCurrentVideo(currentVideo + 1);
    }
  };

  const prevVideo = () => {
    if (currentVideo > 0) {
      setCurrentVideo(currentVideo - 1);
    }
  };

  const handleVideoClick = (productId: number) => {
    navigate(`/product/${productId}`);
  };

  return (
    <div className="min-h-screen bg-gray-900">
      {/* Header */}
      <div className="bg-gradient-to-r from-yellow-50 to-blue-50 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl font-bold text-gray-800 mb-4">🎥 الفيديوهات التعليمية</h1>
          <p className="text-lg text-gray-600">
            اكتشفي أفضل الطرق لتعليم طفلك من خلال فيديوهاتنا التفاعلية
          </p>
          <button
            onClick={() => setLanguage(language === 'ar' ? 'en' : 'ar')}
            className="mt-4 bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors"
          >
            {language === 'ar' ? 'English' : 'عربي'}
          </button>
        </div>
      </div>

      {/* Video Container */}
      <div 
        ref={containerRef}
        className="relative h-screen overflow-hidden"
        style={{ height: 'calc(100vh - 120px)' }}
      >
        {videos.map((video, index) => (
          <div
            key={video.id}
            className={`absolute inset-0 transition-transform duration-500 ease-in-out ${
              index === currentVideo ? 'translate-y-0' : 
              index < currentVideo ? '-translate-y-full' : 'translate-y-full'
            }`}
          >
            <div className="relative w-full h-full flex items-center justify-center bg-black">
              {/* Video Element */}
              <div className="relative w-full max-w-md h-full bg-black rounded-2xl overflow-hidden shadow-2xl">
                <video
                  ref={el => videoRefs.current[index] = el}
                  className="w-full h-full object-cover"
                  poster={video.thumbnail}
                  muted={isMuted}
                  loop
                  playsInline
                >
                  <source src={video.videoUrl} type="video/mp4" />
                </video>

                {/* Video Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/30">
                  {/* Top Info */}
                  <div className="absolute top-4 left-4 right-4">
                    <div className="flex items-center justify-between">
                      <span className="bg-blue-500 text-white px-3 py-1 rounded-full text-sm font-medium">
                        {language === 'ar' ? video.category : video.categoryEn}
                      </span>
                      <button
                        onClick={() => setLanguage(language === 'ar' ? 'en' : 'ar')}
                        className="bg-white/20 text-white px-3 py-1 rounded-full text-sm"
                      >
                        {language === 'ar' ? 'EN' : 'AR'}
                      </button>
                    </div>
                  </div>

                  {/* Center Play Button */}
                  <div className="absolute inset-0 flex items-center justify-center">
                    <button
                      onClick={togglePlay}
                      className="bg-white/20 backdrop-blur-sm p-4 rounded-full hover:bg-white/30 transition-colors"
                    >
                      {isPlaying ? (
                        <Pause className="h-8 w-8 text-white" />
                      ) : (
                        <Play className="h-8 w-8 text-white ml-1" />
                      )}
                    </button>
                  </div>

                  {/* Bottom Info */}
                  <div className="absolute bottom-0 left-0 right-0 p-4">
                    <div className="mb-4">
                      <h3 className="text-white font-bold text-lg mb-2">
                        {language === 'ar' ? video.title : video.titleEn}
                      </h3>
                      <p className="text-white/80 text-sm mb-2">
                        {language === 'ar' ? video.description : video.descriptionEn}
                      </p>
                      <p className="text-white/60 text-xs">
                        بواسطة {language === 'ar' ? video.author : video.authorEn}
                      </p>
                    </div>

                    {/* Captions */}
                    <div className="bg-black/50 backdrop-blur-sm rounded-lg p-3 mb-4">
                      <p className="text-white text-sm">
                        {language === 'ar' ? video.captions.ar : video.captions.en}
                      </p>
                    </div>

                    {/* CTA Button */}
                    <button
                      onClick={() => handleVideoClick(video.relatedProduct.id)}
                      className="w-full bg-gradient-to-r from-yellow-400 to-orange-400 text-gray-800 font-bold py-3 px-6 rounded-xl hover:from-yellow-500 hover:to-orange-500 transition-all duration-300 transform hover:scale-105 shadow-lg mb-4"
                    >
                      اكتشف {language === 'ar' ? video.relatedProduct.title : video.relatedProduct.titleEn} ←
                    </button>
                  </div>
                </div>

                {/* Right Side Actions */}
                <div className="absolute right-4 bottom-32 flex flex-col space-y-4">
                  <button className="bg-white/20 backdrop-blur-sm p-3 rounded-full text-white hover:bg-white/30 transition-colors">
                    <Heart className="h-6 w-6" />
                    <span className="text-xs block mt-1">{video.likes}</span>
                  </button>
                  <button className="bg-white/20 backdrop-blur-sm p-3 rounded-full text-white hover:bg-white/30 transition-colors">
                    <MessageCircle className="h-6 w-6" />
                    <span className="text-xs block mt-1">{video.comments}</span>
                  </button>
                  <button className="bg-white/20 backdrop-blur-sm p-3 rounded-full text-white hover:bg-white/30 transition-colors">
                    <Share2 className="h-6 w-6" />
                    <span className="text-xs block mt-1">{video.shares}</span>
                  </button>
                  <button
                    onClick={toggleMute}
                    className="bg-white/20 backdrop-blur-sm p-3 rounded-full text-white hover:bg-white/30 transition-colors"
                  >
                    {isMuted ? <VolumeX className="h-6 w-6" /> : <Volume2 className="h-6 w-6" />}
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}

        {/* Navigation Arrows */}
        <div className="absolute right-8 top-1/2 transform -translate-y-1/2 flex flex-col space-y-4">
          <button
            onClick={prevVideo}
            disabled={currentVideo === 0}
            className={`p-3 rounded-full transition-colors ${
              currentVideo === 0 
                ? 'bg-gray-600 text-gray-400 cursor-not-allowed' 
                : 'bg-white/20 text-white hover:bg-white/30'
            }`}
          >
            <ChevronUp className="h-6 w-6" />
          </button>
          <button
            onClick={nextVideo}
            disabled={currentVideo === videos.length - 1}
            className={`p-3 rounded-full transition-colors ${
              currentVideo === videos.length - 1 
                ? 'bg-gray-600 text-gray-400 cursor-not-allowed' 
                : 'bg-white/20 text-white hover:bg-white/30'
            }`}
          >
            <ChevronDown className="h-6 w-6" />
          </button>
        </div>

        {/* Video Counter */}
        <div className="absolute left-8 top-1/2 transform -translate-y-1/2">
          <div className="bg-white/20 backdrop-blur-sm rounded-full px-4 py-2 text-white">
            <span className="text-sm">{currentVideo + 1} / {videos.length}</span>
          </div>
        </div>
      </div>

      {/* Instructions */}
      <div className="bg-gray-800 text-white py-4">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-sm">
            استخدم عجلة الماوس أو الأسهم للتنقل بين الفيديوهات • انقر على الفيديو للتشغيل/الإيقاف
          </p>
        </div>
      </div>
    </div>
  );
};

export default Videos;