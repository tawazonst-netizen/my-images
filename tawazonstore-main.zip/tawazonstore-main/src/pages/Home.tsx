import React from 'react';
import Hero from '../components/Hero';
import FeaturedProducts from '../components/FeaturedProducts';
import VideoPreview from '../components/VideoPreview';
import Testimonials from '../components/Testimonials';
import NewsletterSignup from '../components/NewsletterSignup';

const Home = () => {
  // Sample videos data for preview
  const sampleVideos = [
    {
      id: 1,
      title: 'كيف تعلمين طفلك القراءة؟',
      titleEn: 'How to Teach Your Child to Read?',
      category: '📚 نصائح للأهالي',
      categoryEn: '📚 Parent Tips',
      thumbnail: 'https://images.pexels.com/photos/4491461/pexels-photo-4491461.jpeg?auto=compress&cs=tinysrgb&w=400',
      description: 'تعلمي أفضل الطرق لتعليم طفلك القراءة بطريقة ممتعة وتفاعلية',
      descriptionEn: 'Learn the best ways to teach your child reading in a fun and interactive way',
      author: 'د. فاطمة الزهراني',
      authorEn: 'Dr. Fatima Al-Zahrani',
      likes: 245,
      relatedProduct: {
        id: 1,
        title: 'كتاب الحروف المتحركة',
        titleEn: 'Interactive Letters Book'
      }
    },
    {
      id: 2,
      title: 'أنشطة ممتعة مع كتب توازن',
      titleEn: 'Fun Activities with Tawazon Books',
      category: '🎲 أنشطة من منتجاتنا',
      categoryEn: '🎲 Product Activities',
      thumbnail: 'https://images.pexels.com/photos/5428836/pexels-photo-5428836.jpeg?auto=compress&cs=tinysrgb&w=400',
      description: 'شاهدي كيف يمكن استخدام كتبنا التفاعلية في أنشطة تعليمية متنوعة',
      descriptionEn: 'See how our interactive books can be used in various educational activities',
      author: 'أ. أحمد الشامي',
      authorEn: 'Mr. Ahmed Al-Shami',
      likes: 189,
      relatedProduct: {
        id: 2,
        title: 'مجموعة القراءة التفاعلية',
        titleEn: 'Interactive Reading Set'
      }
    },
    {
      id: 3,
      title: 'تجربة أم سارة مع ابنتها',
      titleEn: 'Sara\'s Experience with Her Daughter',
      category: '👩‍👦 تجارب الأهالي',
      categoryEn: '👩‍👦 Parent Reviews',
      thumbnail: 'https://images.pexels.com/photos/4474035/pexels-photo-4474035.jpeg?auto=compress&cs=tinysrgb&w=400',
      description: 'استمعي لتجربة الأم سارة وكيف ساعدت كتب توازن في تطوير مهارات ابنتها',
      descriptionEn: 'Listen to Sara\'s experience and how Tawazon books helped develop her daughter\'s skills',
      author: 'سارة أحمد',
      authorEn: 'Sara Ahmed',
      likes: 312,
      relatedProduct: {
        id: 3,
        title: 'سلسلة كتابي الأول',
        titleEn: 'My First Book Series'
      }
    }
  ];

  return (
    <div>
      <Hero />
      <FeaturedProducts />
      <VideoPreview videos={sampleVideos} />
      <Testimonials />
      <NewsletterSignup />
    </div>
  );
};

export default Home;