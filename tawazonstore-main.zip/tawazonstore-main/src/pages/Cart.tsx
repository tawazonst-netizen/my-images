import React from 'react';
import { useCart } from '../context/CartContext';
import { Minus, Plus, Trash2, ShoppingBag, MessageCircle } from 'lucide-react';

const Cart = () => {
  const { state, dispatch, generateWhatsAppMessage } = useCart();

  const updateQuantity = (id: number, quantity: number) => {
    dispatch({ type: 'UPDATE_QUANTITY', payload: { id, quantity } });
  };

  const removeItem = (id: number) => {
    dispatch({ type: 'REMOVE_ITEM', payload: id });
  };

  const handleWhatsAppOrder = () => {
    const message = generateWhatsAppMessage();
    const whatsappUrl = `https://wa.me/905516749445?text=${message}`;
    window.open(whatsappUrl, '_blank');
  };

  if (state.items.length === 0) {
    return (
      <div className="py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="bg-gray-100 rounded-full w-32 h-32 flex items-center justify-center mx-auto mb-8">
            <ShoppingBag className="h-16 w-16 text-gray-400" />
          </div>
          <h1 className="text-3xl font-bold text-gray-800 mb-4">سلة التسوق فارغة</h1>
          <p className="text-xl text-gray-600 mb-8">لم تقم بإضافة أي منتجات بعد</p>
          <button 
            onClick={() => window.location.href = '/shop'}
            className="btn-primary"
          >
            تسوق الآن
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="py-8">
      {/* Header */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-8">
        <h1 className="text-4xl font-bold text-gray-800 mb-4">سلة التسوق</h1>
        <p className="text-lg text-gray-600">راجع منتجاتك واطلب عبر الواتساب</p>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2 space-y-4">
            {state.items.map((item) => (
              <div key={item.id} className="card p-6">
                <div className="flex items-center space-x-4">
                  <img
                    src={item.image}
                    alt={item.title}
                    className="w-20 h-20 object-cover rounded-lg"
                  />
                  <div className="flex-1">
                    <h3 className="text-lg font-bold text-gray-800">{item.title}</h3>
                    <p className="text-sm text-gray-600">{item.ageRange}</p>
                    <div className="flex items-center space-x-2 mt-2">
                      <span className="text-lg font-bold text-blue-600">{item.price} ر.س</span>
                      <span className="text-sm text-gray-400 line-through">{item.originalPrice} ر.س</span>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <button
                      onClick={() => updateQuantity(item.id, item.quantity - 1)}
                      className="bg-gray-200 hover:bg-gray-300 p-2 rounded-lg"
                    >
                      <Minus className="h-4 w-4" />
                    </button>
                    <span className="font-semibold text-lg w-8 text-center">{item.quantity}</span>
                    <button
                      onClick={() => updateQuantity(item.id, item.quantity + 1)}
                      className="bg-gray-200 hover:bg-gray-300 p-2 rounded-lg"
                    >
                      <Plus className="h-4 w-4" />
                    </button>
                  </div>
                  <button
                    onClick={() => removeItem(item.id)}
                    className="text-red-500 hover:text-red-700 p-2"
                  >
                    <Trash2 className="h-5 w-5" />
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Order Summary */}
          <div className="card p-6 h-fit">
            <h3 className="text-xl font-bold text-gray-800 mb-4">ملخص الطلب</h3>
            <div className="space-y-3 mb-6">
              <div className="flex justify-between">
                <span>المجموع الفرعي</span>
                <span>{state.total.toFixed(2)} ر.س</span>
              </div>
              <div className="flex justify-between">
                <span>الشحن</span>
                <span className="text-green-600">حسب الموقع</span>
              </div>
              <div className="border-t pt-3 flex justify-between font-bold text-lg">
                <span>المجموع الكلي</span>
                <span className="text-blue-600">{state.total.toFixed(2)} ر.س</span>
              </div>
            </div>
            
            {/* WhatsApp Order Button */}
            <button 
              onClick={handleWhatsAppOrder}
              className="w-full bg-green-500 hover:bg-green-600 text-white font-semibold py-4 px-6 rounded-xl transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl flex items-center justify-center space-x-3"
            >
              <MessageCircle className="h-6 w-6" />
              <span>اطلب عبر الواتساب</span>
            </button>
            
            <div className="mt-4 text-center">
              <p className="text-sm text-gray-600">
                سيتم فتح الواتساب مع تفاصيل طلبك جاهزة للإرسال
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Cart;