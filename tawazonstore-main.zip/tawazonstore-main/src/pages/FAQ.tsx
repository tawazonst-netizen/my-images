import React, { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';

const FAQ = () => {
  const [openItems, setOpenItems] = useState<number[]>([]);

  const toggleItem = (index: number) => {
    setOpenItems(prev => 
      prev.includes(index) 
        ? prev.filter(item => item !== index)
        : [...prev, index]
    );
  };

  const faqData = [
    {
      question: 'ما هي طرق الدفع المتاحة؟',
      answer: 'نوفر عدة طرق للدفع: الدفع عند الاستلام، البطاقات الائتمانية (فيزا، ماستركارد)، التحويل البنكي، والدفع عبر التطبيقات الرقمية مثل آبل باي.'
    },
    {
      question: 'كم تستغرق عملية التوصيل؟',
      answer: 'التوصيل داخل إسطنبول يستغرق 1-2 يوم عمل، والتوصيل للدول الأخرى يستغرق 5-10 أيام عمل حسب الموقع. الشحن مجاني للطلبات فوق 150 ريال سعودي.'
    },
    {
      question: 'ما هي الفئات العمرية المناسبة لكل منتج؟',
      answer: 'منتجاتنا مصنفة حسب الفئات العمرية: سلسلة كتابي الأول (1-4 سنوات)، سلسلة هيا نتعلم (3-6 سنوات)، الألعاب التعليمية (4-8 سنوات)، وأدوات الدعم للمعلمين (جميع الأعمار).'
    },
    {
      question: 'هل يمكنني إرجاع المنتج إذا لم يعجبني؟',
      answer: 'نعم، لديك 14 يوماً من تاريخ الاستلام لإرجاع المنتج في حالته الأصلية. المنتجات المستعملة أو التالفة لا يمكن إرجاعها. تكلفة الشحن على العميل.'
    },
    {
      question: 'هل المنتجات متوفرة باللغة العربية والإنجليزية؟',
      answer: 'معظم منتجاتنا متوفرة باللغة العربية، وبعض المنتجات متوفرة بنسختين عربية وإنجليزية. يمكنك التحقق من اللغات المتاحة في صفحة كل منتج.'
    },
    {
      question: 'كيف أعرف المنتج المناسب لطفلي؟',
      answer: 'يمكنك الاطلاع على الفئة العمرية المقترحة لكل منتج، أو التواصل معنا للحصول على استشارة مجانية. فريقنا من المختصين يساعدك في اختيار المنتج الأنسب.'
    },
    {
      question: 'هل تقدمون خصومات للمدارس والمؤسسات التعليمية؟',
      answer: 'نعم، نقدم خصومات خاصة للمدارس ورياض الأطفال والمؤسسات التعليمية. تتراوح الخصومات من 15% إلى 30% حسب كمية الطلب. تواصل معنا للحصول على عرض مخصص.'
    },
    {
      question: 'هل المنتجات آمنة للأطفال؟',
      answer: 'جميع منتجاتنا حاصلة على شهادات الأمان الدولية وخالية من المواد الضارة. نستخدم مواد عالية الجودة وآمنة 100% للأطفال في جميع الأعمار.'
    },
    {
      question: 'هل يمكنني تتبع طلبي؟',
      answer: 'نعم، ستحصل على رقم تتبع فور شحن طلبك عبر البريد الإلكتروني والرسائل النصية. يمكنك تتبع طلبك في أي وقت من خلال موقعنا أو التطبيق.'
    },
    {
      question: 'هل تقدمون ضمان على المنتجات؟',
      answer: 'نقدم ضمان جودة لمدة سنة واحدة على جميع منتجاتنا. إذا ظهر أي عيب في التصنيع، سنستبدل المنتج مجاناً خلال فترة الضمان.'
    }
  ];

  return (
    <div className="py-8">
      {/* Header */}
      <div className="bg-gradient-to-r from-yellow-50 to-blue-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl font-bold text-gray-800 mb-6">الأسئلة الشائعة</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            إجابات سريعة على أكثر الأسئلة شيوعاً حول منتجاتنا وخدماتنا
          </p>
        </div>
      </div>

      {/* FAQ Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="space-y-4">
          {faqData.map((item, index) => (
            <div key={index} className="card">
              <button
                onClick={() => toggleItem(index)}
                className="w-full p-6 text-right flex items-center justify-between hover:bg-gray-50 transition-colors"
              >
                <span className="text-lg font-semibold text-gray-800">
                  {item.question}
                </span>
                {openItems.includes(index) ? (
                  <ChevronUp className="h-6 w-6 text-gray-500" />
                ) : (
                  <ChevronDown className="h-6 w-6 text-gray-500" />
                )}
              </button>
              {openItems.includes(index) && (
                <div className="px-6 pb-6">
                  <p className="text-gray-700 leading-relaxed text-lg">
                    {item.answer}
                  </p>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Still Have Questions */}
        <div className="mt-16 text-center">
          <div className="bg-gradient-to-r from-blue-500 to-green-500 rounded-3xl p-8 text-white">
            <h3 className="text-2xl font-bold mb-4">لم تجد إجابة سؤالك؟</h3>
            <p className="text-lg mb-6 opacity-90">
              فريق خدمة العملاء جاهز لمساعدتك في أي وقت
            </p>
            <button className="bg-white text-blue-600 font-semibold py-4 px-8 rounded-xl hover:bg-gray-100 transition-colors">
              تواصل معنا
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FAQ;