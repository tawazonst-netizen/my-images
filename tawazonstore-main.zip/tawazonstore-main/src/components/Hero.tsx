import React from 'react';
import { ArrowLeft, MessageCircle, ShoppingCart, BookOpen } from 'lucide-react';

const Hero = () => {
  return (
    <section className="relative bg-gradient-to-br from-yellow-100 via-blue-50 to-green-50 py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <div className="text-center lg:text-right">
            <h1 className="text-4xl md:text-6xl font-bold text-gray-800 leading-tight mb-6">
              مكتبة توازن..
              <span className="block text-blue-600">شريك طفلك في رحلة تعلم ممتعة</span>
            </h1>
            <p className="text-xl text-gray-600 mb-8 leading-relaxed">
              اكتشف عالماً من الكتب التفاعلية والألعاب التعليمية المصممة خصيصاً لتنمية مهارات طفلك
              في مرحلة الطفولة المبكرة بطريقة ممتعة ومتوازنة
            </p>
            
            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-end">
              <button 
                onClick={() => window.location.href = '/shop'}
                className="btn-primary flex items-center justify-center space-x-2"
              >
                <ShoppingCart className="h-5 w-5" />
                <span>تسوق الآن</span>
              </button>
              <a 
                href="https://wa.me/905516749445?text=مرحباً%20أرغب%20بالاستفسار%20عن%20منتجاتكم"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-green-500 hover:bg-green-600 text-white font-semibold py-3 px-6 rounded-xl transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl flex items-center justify-center space-x-2"
              >
                <MessageCircle className="h-5 w-5" />
                <span>تواصل معنا</span>
              </a>
            </div>
          </div>

          {/* Hero Image */}
          <div className="relative">
            <div className="relative bg-white rounded-3xl p-8 shadow-2xl transform rotate-3 hover:rotate-0 transition-transform duration-500">
              <img
                src="https://images.pexels.com/photos/4473775/pexels-photo-4473775.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="طفل يقرأ كتاباً تفاعلياً"
                className="w-full h-96 object-cover rounded-2xl"
              />
              <div className="absolute -top-4 -right-4 bg-yellow-400 text-yellow-800 font-bold py-2 px-4 rounded-xl shadow-lg">
                جديد! 🌟
              </div>
            </div>
            
            {/* Floating Cards */}
            <div className="absolute -bottom-6 -left-6 bg-white rounded-xl shadow-lg p-4 transform hover:scale-105 transition-transform">
              <div className="flex items-center space-x-3">
                <div className="bg-green-100 p-2 rounded-lg">
                  <BookOpen className="h-6 w-6 text-green-600" />
                </div>
                <div>
                  <p className="font-semibold text-gray-800">500+ كتاب</p>
                  <p className="text-sm text-gray-600">تفاعلي وتعليمي</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Decorative Elements */}
      <div className="absolute top-20 left-10 w-20 h-20 bg-yellow-300 rounded-full opacity-20 animate-pulse"></div>
      <div className="absolute bottom-20 right-10 w-16 h-16 bg-blue-300 rounded-full opacity-20 animate-bounce"></div>
      <div className="absolute top-1/2 left-1/4 w-12 h-12 bg-green-300 rounded-full opacity-20"></div>
    </section>
  );
};

export default Hero;