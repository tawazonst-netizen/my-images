import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Star, ShoppingCart, Heart, ArrowLeft } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useCurrency } from '../context/CurrencyContext';

const FeaturedProducts = () => {
  const { dispatch } = useCart();
  const { formatPrice } = useCurrency();
  const navigate = useNavigate();

  const products = [
    {
      id: 1,
      title: 'كتابي الأول في التعرف على الألوان',
      titleEn: 'My First Book Series',
      priceUSD: 15,
      image: 'https://images.pexels.com/photos/4473409/pexels-photo-4473409.jpeg?auto=compress&cs=tinysrgb&w=600',
      rating: 4.9,
      reviews: 124,
      category: 'books',
      ageRange: '2-4 سنوات'
    },
    {
      id: 2,
      title: 'مجموعة القراءة التفاعلية',
      titleEn: 'Let\'s Learn Series',
      priceUSD: 35,
      image: 'https://images.pexels.com/photos/5428836/pexels-photo-5428836.jpeg?auto=compress&cs=tinysrgb&w=600',
      rating: 4.8,
      reviews: 89,
      category: 'educational',
      ageRange: '4-8 سنوات'
    },
    {
      id: 3,
      title: 'لعبة الأرقام السحرية',
      titleEn: 'Interactive Educational Games',
      priceUSD: 25,
      image: 'https://images.pexels.com/photos/8613089/pexels-photo-8613089.jpeg?auto=compress&cs=tinysrgb&w=600',
      rating: 5.0,
      reviews: 156,
      category: 'games',
      ageRange: '3-6 سنوات'
    },
    {
      id: 4,
      title: 'أدوات دعم للمعلمين',
      titleEn: 'Teacher Support Tools',
      priceUSD: 30,
      image: 'https://images.pexels.com/photos/8923059/pexels-photo-8923059.jpeg?auto=compress&cs=tinysrgb&w=600',
      rating: 4.7,
      reviews: 67,
      category: 'tools',
      ageRange: 'جميع الأعمار'
    }
  ];

  const addToCart = (product: typeof products[0]) => {
    dispatch({
      type: 'ADD_ITEM',
      payload: {
        id: product.id,
        title: product.title,
        price: product.priceUSD,
        originalPrice: product.priceUSD * 1.2,
        image: product.image,
        ageRange: product.ageRange
      }
    });
  };
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-800 mb-4">
            منتجاتنا المميزة
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            مجموعة مختارة بعناية من أفضل المواد التعليمية لتطوير مهارات طفلك في بيئة تعلم ممتعة
          </p>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-8">
          {products.map((product) => (
            <div key={product.id} className="card p-6 group cursor-pointer"
              onClick={() => navigate(`/product/${product.id}`)}>
              {/* Product Image */}
              <div className="relative mb-6">
                <img
                  src={product.image}
                  alt={product.title}
                  className="w-full h-48 object-cover rounded-xl"
                />
                <button className="absolute top-3 right-3 bg-white p-2 rounded-full shadow-lg opacity-0 group-hover:opacity-100 transition-all duration-300 hover:bg-red-50">
                  <Heart className="h-5 w-5 text-gray-600 hover:text-red-500" />
                </button>
              </div>

              {/* Product Info */}
              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-bold text-gray-800 mb-2">{product.title}</h3>
                  <p className="text-sm text-gray-600">{product.ageRange}</p>
                </div>

                {/* Rating */}
                <div className="flex items-center space-x-2">
                  <div className="flex text-yellow-400">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`h-4 w-4 ${i < Math.floor(product.rating) ? 'fill-current' : ''}`}
                      />
                    ))}
                  </div>
                  <span className="text-sm text-gray-600">({product.reviews})</span>
                </div>

                {/* Price */}
                <div className="flex items-center space-x-3">
                  <span className="text-2xl font-bold text-blue-600">{formatPrice(product.priceUSD)}</span>
                </div>

                {/* Add to Cart Button */}
                <button 
                  onClick={() => addToCart(product)}
                  className="w-full btn-primary flex items-center justify-center space-x-2"
                >
                  <ShoppingCart className="h-5 w-5" />
                  <span>أضف للسلة</span>
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* View All Button */}
        <div className="text-center mt-12">
          <button 
            onClick={() => window.location.href = '/shop'}
            className="btn-primary flex items-center justify-center space-x-2 mx-auto"
          >
            <span>عرض جميع المنتجات</span>
            <ArrowLeft className="h-5 w-5" />
          </button>
        </div>
      </div>
    </section>
  );
};

export default FeaturedProducts;