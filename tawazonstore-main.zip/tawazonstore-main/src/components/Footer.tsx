import React from 'react';
import { Link } from 'react-router-dom';
import { Phone, Mail, MessageCircle } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-800 text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Company Info */}
          <div>
            <h3 className="text-xl font-bold mb-4 text-yellow-400">مكتبة التوازن</h3>
            <p className="text-gray-300 mb-4">
              مكتبتك المفضلة للكتب والقرطاسية والألعاب التعليمية
            </p>
            <p className="text-gray-300">
              Your favorite library for books, stationery, and educational games
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-4 text-yellow-400">روابط سريعة</h4>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-gray-300 hover:text-yellow-400 transition-colors">
                  الرئيسية
                </Link>
              </li>
              <li>
                <Link to="/shop" className="text-gray-300 hover:text-yellow-400 transition-colors">
                  المتجر
                </Link>
              </li>
              <li>
                <Link to="/videos" className="text-gray-300 hover:text-yellow-400 transition-colors">
                  الفيديوهات
                </Link>
              </li>
              <li>
                <Link to="/about" className="text-gray-300 hover:text-yellow-400 transition-colors">
                  من نحن
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-gray-300 hover:text-yellow-400 transition-colors">
                  اتصل بنا
                </Link>
              </li>
            </ul>
          </div>

          {/* Policies */}
          <div>
            <h4 className="text-lg font-semibold mb-4 text-yellow-400">السياسات</h4>
            <ul className="space-y-2">
              <li>
                <Link to="/exchange-policy" className="text-gray-300 hover:text-yellow-400 transition-colors">
                  سياسة الاستبدال
                </Link>
              </li>
              <li>
                <Link to="/terms-of-use" className="text-gray-300 hover:text-yellow-400 transition-colors">
                  شروط الاستخدام
                </Link>
              </li>
              <li>
                <Link to="/privacy-policy" className="text-gray-300 hover:text-yellow-400 transition-colors">
                  سياسة الخصوصية
                </Link>
              </li>
              <li>
                <Link to="/user-guide" className="text-gray-300 hover:text-yellow-400 transition-colors">
                  دليل الاستخدام
                </Link>
              </li>
              <li>
                <Link to="/faq" className="text-gray-300 hover:text-yellow-400 transition-colors">
                  الأسئلة الشائعة
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-lg font-semibold mb-4 text-yellow-400">تواصل معنا</h4>
            <div className="space-y-3">
              <a 
                href="tel:+905516749445" 
                className="flex items-center text-gray-300 hover:text-yellow-400 transition-colors"
              >
                <Phone className="w-4 h-4 mr-2" />
                +90 551 674 9445
              </a>
              <a 
                href="mailto:info@tawazonstore.com" 
                className="flex items-center text-gray-300 hover:text-yellow-400 transition-colors"
              >
                <Mail className="w-4 h-4 mr-2" />
                info@tawazonstore.com
              </a>
              <a 
                href="https://wa.me/905516749445?text=مرحباً%20أرغب%20بالاستفسار%20عن%20منتجاتكم" 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center text-gray-300 hover:text-yellow-400 transition-colors"
              >
                <MessageCircle className="w-4 h-4 mr-2" />
                WhatsApp
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-8 pt-8 text-center">
          <p className="text-gray-300">
            © 2024 مكتبة التوازن - جميع الحقوق محفوظة | Tawazon Library - All Rights Reserved
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;