import React from 'react';
import { X, Star, ShoppingCart, Heart } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useCurrency } from '../context/CurrencyContext';

interface Product {
  id: number;
  title: string;
  priceUSD: number;
  image: string;
  rating: number;
  reviews: number;
  ageRange: string;
  description: string;
  weight: number;
}

interface QuickViewProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
}

const QuickView: React.FC<QuickViewProps> = ({ product, isOpen, onClose }) => {
  const { dispatch } = useCart();
  const { formatPrice } = useCurrency();

  if (!isOpen || !product) return null;

  const addToCart = () => {
    dispatch({
      type: 'ADD_ITEM',
      payload: {
        id: product.id,
        title: product.title,
        price: product.priceUSD,
        originalPrice: product.priceUSD * 1.2,
        image: product.image,
        ageRange: product.ageRange
      }
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-gray-800">عرض سريع</h2>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <X className="h-6 w-6 text-gray-600" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Product Image */}
            <div>
              <img
                src={product.image}
                alt={product.title}
                className="w-full h-80 object-cover rounded-xl shadow-lg"
              />
            </div>

            {/* Product Info */}
            <div>
              <h3 className="text-2xl font-bold text-gray-800 mb-3">{product.title}</h3>
              <p className="text-gray-600 mb-4">{product.description}</p>

              {/* Rating */}
              <div className="flex items-center space-x-2 mb-4">
                <div className="flex text-yellow-400">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`h-4 w-4 ${i < Math.floor(product.rating) ? 'fill-current' : ''}`}
                    />
                  ))}
                </div>
                <span className="text-sm text-gray-600">({product.reviews} تقييم)</span>
              </div>

              {/* Price */}
              <div className="flex items-center space-x-3 mb-4">
                <span className="text-2xl font-bold text-blue-600">{formatPrice(product.priceUSD)}</span>
                <span className="text-sm text-gray-500">الوزن: {product.weight} كيلو</span>
              </div>

              {/* Age Range */}
              <div className="mb-6">
                <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm font-medium">
                  العمر المناسب: {product.ageRange}
                </span>
              </div>

              {/* Actions */}
              <div className="flex space-x-3">
                <button
                  onClick={addToCart}
                  className="btn-primary flex-1 flex items-center justify-center space-x-2"
                >
                  <ShoppingCart className="h-5 w-5" />
                  <span>أضف للسلة</span>
                </button>
                <button className="bg-gray-200 hover:bg-gray-300 p-3 rounded-xl">
                  <Heart className="h-5 w-5 text-gray-600" />
                </button>
              </div>

              {/* Features */}
              <div className="mt-6 text-sm text-gray-600">
                <p>✓ طلب عبر الواتساب</p>
                <p>✓ ضمان الجودة</p>
                <p>✓ إمكانية الإرجاع خلال 14 يوم</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default QuickView;