import React from 'react';
import { Play, ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface Video {
  id: number;
  title: string;
  titleEn: string;
  category: string;
  categoryEn: string;
  thumbnail: string;
  description: string;
  descriptionEn: string;
  author: string;
  authorEn: string;
  likes: number;
  relatedProduct: {
    id: number;
    title: string;
    titleEn: string;
  };
}

interface VideoPreviewProps {
  videos: Video[];
  language?: string;
}

const VideoPreview: React.FC<VideoPreviewProps> = ({ videos, language = 'ar' }) => {
  const navigate = useNavigate();

  return (
    <section className="py-20 bg-gradient-to-br from-yellow-50 via-blue-50 to-green-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-800 mb-4">
            🎥 الفيديوهات التعليمية
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-8">
            شاهدي أحدث النصائح والأنشطة التعليمية من خبرائنا
          </p>
          <button
            onClick={() => navigate('/videos')}
            className="btn-primary flex items-center justify-center space-x-2 mx-auto"
          >
            <span>شاهد جميع الفيديوهات</span>
            <ArrowLeft className="h-5 w-5" />
          </button>
        </div>

        {/* Videos Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {videos.slice(0, 3).map((video) => (
            <div
              key={video.id}
              className="card p-0 overflow-hidden group cursor-pointer transform hover:scale-105 transition-all duration-300"
              onClick={() => navigate('/videos')}
            >
              {/* Video Thumbnail */}
              <div className="relative aspect-[9/16] bg-gray-900 rounded-t-2xl overflow-hidden">
                <img
                  src={video.thumbnail}
                  alt={language === 'ar' ? video.title : video.titleEn}
                  className="w-full h-full object-cover"
                />
                
                {/* Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/30">
                  {/* Category Badge */}
                  <div className="absolute top-4 left-4">
                    <span className="bg-blue-500 text-white px-3 py-1 rounded-full text-sm font-medium">
                      {language === 'ar' ? video.category : video.categoryEn}
                    </span>
                  </div>

                  {/* Play Button */}
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="bg-white/20 backdrop-blur-sm p-4 rounded-full group-hover:bg-white/30 transition-colors">
                      <Play className="h-8 w-8 text-white ml-1" />
                    </div>
                  </div>

                  {/* Video Info */}
                  <div className="absolute bottom-0 left-0 right-0 p-4">
                    <h3 className="text-white font-bold text-lg mb-2">
                      {language === 'ar' ? video.title : video.titleEn}
                    </h3>
                    <p className="text-white/80 text-sm mb-2">
                      {language === 'ar' ? video.description : video.descriptionEn}
                    </p>
                    <p className="text-white/60 text-xs">
                      بواسطة {language === 'ar' ? video.author : video.authorEn}
                    </p>
                  </div>

                  {/* Likes */}
                  <div className="absolute top-4 right-4">
                    <div className="bg-white/20 backdrop-blur-sm rounded-full px-3 py-1">
                      <span className="text-white text-sm">❤️ {video.likes}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* CTA Section */}
              <div className="p-6">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    navigate(`/product/${video.relatedProduct.id}`);
                  }}
                  className="w-full bg-gradient-to-r from-yellow-400 to-orange-400 text-gray-800 font-bold py-3 px-6 rounded-xl hover:from-yellow-500 hover:to-orange-500 transition-all duration-300 transform hover:scale-105 shadow-lg"
                >
                  اكتشف {language === 'ar' ? video.relatedProduct.title : video.relatedProduct.titleEn} ←
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default VideoPreview;