import React from 'react';
import { Mail, Gift } from 'lucide-react';

const NewsletterSignup = () => {
  return (
    <section className="py-20 bg-gradient-to-r from-yellow-100 to-orange-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-3xl p-12 shadow-2xl">
          <div className="text-center">
            <div className="bg-gradient-to-r from-blue-500 to-green-500 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
              <Mail className="h-10 w-10 text-white" />
            </div>
            
            <h2 className="text-4xl font-bold text-gray-800 mb-4">
              اشترك في النشرة الإخبارية
            </h2>
            <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
              احصل على أحدث المنتجات، النصائح التعليمية، والعروض الحصرية مباشرة في بريدك الإلكتروني
            </p>

            {/* Benefits */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              {[
                {
                  icon: <Gift className="h-6 w-6" />,
                  title: 'عروض حصرية',
                  description: 'خصومات خاصة للمشتركين'
                },
                {
                  icon: <Mail className="h-6 w-6" />,
                  title: 'نصائح أسبوعية',
                  description: 'مقالات تعليمية متخصصة'
                },
                {
                  icon: <Gift className="h-6 w-6" />,
                  title: 'منتجات جديدة',
                  description: 'أول من يعلم بالإصدارات الجديدة'
                }
              ].map((benefit, index) => (
                <div key={index} className="flex items-center space-x-3 bg-gray-50 p-4 rounded-xl">
                  <div className="bg-blue-100 text-blue-600 p-2 rounded-lg">
                    {benefit.icon}
                  </div>
                  <div className="text-right">
                    <h4 className="font-semibold text-gray-800">{benefit.title}</h4>
                    <p className="text-sm text-gray-600">{benefit.description}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* Signup Form */}
            <div className="max-w-md mx-auto">
              <form onSubmit={(e) => { e.preventDefault(); alert('شكراً لاشتراكك! سنتواصل معك قريباً.'); }}>
                <div className="flex gap-3">
                  <input
                    type="email"
                    placeholder="أدخل بريدك الإلكتروني"
                    required
                    className="flex-1 px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                  <button type="submit" className="btn-primary whitespace-nowrap">
                    اشترك الآن
                  </button>
                </div>
              </form>
              <p className="text-sm text-gray-500 mt-3">
                باشتراكك توافق على <a href="/privacy-policy" className="text-blue-600 hover:underline">سياسة الخصوصية</a>
              </p>
            </div>

            {/* Special Offer */}
            <div className="mt-8 bg-yellow-100 border-2 border-yellow-300 rounded-xl p-6">
              <p className="text-lg font-semibold text-yellow-800">
                🎁 عرض خاص: احصل على خصم 20% على أول طلب عند الاشتراك!
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default NewsletterSignup;