import React from 'react';
import { Star, Quote, Play } from 'lucide-react';

const Testimonials = () => {
  const testimonials = [
    {
      id: 1,
      name: 'سارة أحمد',
      role: 'أم لطفلين',
      image: 'https://images.pexels.com/photos/3992656/pexels-photo-3992656.jpeg?auto=compress&cs=tinysrgb&w=300',
      content: 'كتب توازن غيرت طريقة تعلم ابنتي تماماً. الآن تحب القراءة وتطلب المزيد من الكتب كل يوم!',
      rating: 5,
      location: 'الرياض، السعودية'
    },
    {
      id: 2,
      name: 'محمد الخالدي',
      role: 'معلم رياض أطفال',
      image: 'https://images.pexels.com/photos/5212317/pexels-photo-5212317.jpeg?auto=compress&cs=tinysrgb&w=300',
      content: 'أستخدم مواد توازن في فصلي. الأطفال متحمسون دائماً وأرى تطوراً ملحوظاً في مهاراتهم اللغوية.',
      rating: 5,
      location: 'دبي، الإمارات'
    },
    {
      id: 3,
      name: 'ليلى عبدالله',
      role: 'أم لثلاثة أطفال',
      image: 'https://images.pexels.com/photos/4474035/pexels-photo-4474035.jpeg?auto=compress&cs=tinysrgb&w=300',
      content: 'الألعاب التعليمية من توازن جعلت وقت التعلم ممتعاً للغاية. أطفالي يتعلمون وهم يلعبون!',
      rating: 5,
      location: 'القاهرة، مصر'
    }
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-800 mb-4">
            ماذا يقول عملاؤنا
          </h2>
          <p className="text-xl text-gray-600">
            آراء الأهالي والمعلمين حول منتجات مكتبة توازن
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial) => (
            <div key={testimonial.id} className="card p-8 relative">
              {/* Quote Icon */}
              <div className="absolute -top-4 right-6">
                <div className="bg-blue-500 p-3 rounded-full">
                  <Quote className="h-6 w-6 text-white" />
                </div>
              </div>

              {/* Content */}
              <div className="pt-8">
                {/* Rating */}
                <div className="flex text-yellow-400 mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 fill-current" />
                  ))}
                </div>

                {/* Review */}
                <p className="text-gray-700 mb-6 leading-relaxed text-lg">
                  "{testimonial.content}"
                </p>

                {/* Author */}
                <div className="flex items-center space-x-4">
                  <img
                    src={testimonial.image}
                    alt={testimonial.name}
                    className="w-12 h-12 rounded-full object-cover"
                  />
                  <div>
                    <h4 className="font-bold text-gray-800">{testimonial.name}</h4>
                    <p className="text-sm text-gray-600">{testimonial.role}</p>
                    <p className="text-xs text-gray-500">{testimonial.location}</p>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Video Testimonial */}
        <div className="mt-16 text-center">
          <div className="bg-gradient-to-r from-blue-500 to-green-500 rounded-3xl p-8 text-white">
            <h3 className="text-2xl font-bold mb-4">شاهد طفلك يتفاعل مع منتجاتنا</h3>
            <p className="text-lg mb-6 opacity-90">فيديو حقيقي من أحد عملائنا يظهر تفاعل الطفل مع الكتاب</p>
            <button className="bg-white text-blue-600 font-semibold py-4 px-8 rounded-xl hover:bg-gray-100 transition-colors flex items-center justify-center space-x-3 mx-auto">
              <Play className="h-6 w-6" />
              <span>شاهد الفيديو</span>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;