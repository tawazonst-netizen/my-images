import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, BookOpen, Globe, ShoppingCart, User, LogOut } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import { useCurrency } from '../context/CurrencyContext';
import LoginModal from './LoginModal';

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [language, setLanguage] = useState('AR');
  const location = useLocation();
  const { state } = useCart();
  const { state: authState, logout } = useAuth();
  const { currency, setCurrency } = useCurrency();

  const navigation = [
    { name: 'الرئيسية', nameEn: 'Home', href: '/' },
    { name: 'من نحن', nameEn: 'About', href: '/about' },
    { name: 'المتجر', nameEn: 'Shop', href: '/shop' },
    { name: 'الفيديوهات', nameEn: 'Videos', href: '/videos' },
    { name: 'المحتوى التعليمي', nameEn: 'Blog', href: '/blog' },
    { name: 'اتصل بنا', nameEn: 'Contact', href: '/contact' },
    { name: 'الأسئلة الشائعة', nameEn: 'FAQ', href: '/faq' },
  ];

  const currencies = [
    { code: 'USD', symbol: '$', rate: 1 },
    { code: 'TRY', symbol: '₺', rate: 30.5 },
    { code: 'EUR', symbol: '€', rate: 0.92 }
  ];

  return (
    <nav className="bg-white shadow-lg sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20">
          {/* Logo */}
          <div className="flex items-center">
            <Link to="/" className="flex items-center space-x-3">
              <div className="bg-gradient-to-r from-blue-500 to-green-500 p-3 rounded-xl">
                <BookOpen className="h-8 w-8 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-800">مكتبة توازن</h1>
                <p className="text-sm text-gray-600">Tawazon Library</p>
              </div>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            {navigation.map((item) => (
              <Link
                key={item.href}
                to={item.href}
                className={`px-4 py-2 rounded-lg font-medium transition-all duration-200 ${
                  location.pathname === item.href
                    ? 'bg-blue-100 text-blue-700'
                    : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                {language === 'AR' ? item.name : item.nameEn}
              </Link>
            ))}
            
            {/* Shopping Cart */}
            <Link
              to="/cart"
              className="relative p-2 text-gray-700 hover:text-blue-600 transition-colors"
            >
              <ShoppingCart className="h-6 w-6" />
              {state.itemCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                  {state.itemCount}
                </span>
              )}
            </Link>

            {/* Currency Selector */}
            <select
              value={currency.code}
              onChange={(e) => {
                const selectedCurrency = currencies.find(c => c.code === e.target.value);
                if (selectedCurrency) setCurrency(selectedCurrency);
              }}
              className="px-3 py-2 bg-gray-100 rounded-lg text-sm font-medium"
            >
              {currencies.map((curr) => (
                <option key={curr.code} value={curr.code}>
                  {curr.code} {curr.symbol}
                </option>
              ))}
            </select>

            {/* User Account */}
            {authState.isAuthenticated ? (
              <div className="flex items-center space-x-4">
                <span className="text-gray-700">مرحباً، {authState.user?.name}</span>
                <button
                  onClick={logout}
                  className="flex items-center space-x-2 px-4 py-2 bg-red-100 text-red-600 rounded-lg hover:bg-red-200 transition-colors"
                >
                  <LogOut className="h-4 w-4" />
                  <span>خروج</span>
                </button>
              </div>
            ) : (
              <button
                onClick={() => setShowLoginModal(true)}
                className="flex items-center space-x-2 px-4 py-2 bg-blue-100 text-blue-600 rounded-lg hover:bg-blue-200 transition-colors"
              >
                <User className="h-4 w-4" />
                <span>دخول</span>
              </button>
            )}

            {/* Language Toggle */}
            <button
              onClick={() => setLanguage(language === 'AR' ? 'EN' : 'AR')}
              className="flex items-center space-x-2 px-4 py-2 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors"
            >
              <Globe className="h-4 w-4" />
              <span className="font-medium">{language}</span>
            </button>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden flex items-center">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-gray-700 hover:text-blue-600 p-2"
            >
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation */}
      {isOpen && (
        <div className="md:hidden bg-white border-t border-gray-200">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            {navigation.map((item) => (
              <Link
                key={item.href}
                to={item.href}
                onClick={() => setIsOpen(false)}
                className={`block px-4 py-3 rounded-lg font-medium transition-all duration-200 ${
                  location.pathname === item.href
                    ? 'bg-blue-100 text-blue-700'
                    : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                {language === 'AR' ? item.name : item.nameEn}
              </Link>
            ))}
            <Link
              to="/cart"
              onClick={() => setIsOpen(false)}
              className="flex items-center justify-between px-4 py-3 text-gray-700 hover:bg-gray-100 rounded-lg font-medium transition-all duration-200"
            >
              <span>سلة التسوق</span>
              <div className="flex items-center space-x-2">
                <ShoppingCart className="h-5 w-5" />
                {state.itemCount > 0 && (
                  <span className="bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                    {state.itemCount}
                  </span>
                )}
              </div>
            </Link>
            
            {/* Mobile User Account */}
            {authState.isAuthenticated ? (
              <div className="px-4 py-3">
                <p className="text-gray-700 mb-2">مرحباً، {authState.user?.name}</p>
                <button
                  onClick={() => {
                    logout();
                    setIsOpen(false);
                  }}
                  className="w-full text-left px-4 py-3 bg-red-100 text-red-600 rounded-lg hover:bg-red-200 transition-colors font-medium"
                >
                  <LogOut className="h-4 w-4 inline mr-2" />
                  تسجيل الخروج
                </button>
              </div>
            ) : (
              <button
                onClick={() => {
                  setShowLoginModal(true);
                  setIsOpen(false);
                }}
                className="w-full text-left px-4 py-3 bg-blue-100 text-blue-600 rounded-lg hover:bg-blue-200 transition-colors font-medium"
              >
                <User className="h-4 w-4 inline mr-2" />
                تسجيل الدخول
              </button>
            )}
            
            <button
              onClick={() => setLanguage(language === 'AR' ? 'EN' : 'AR')}
              className="w-full text-left px-4 py-3 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors font-medium"
            >
              <Globe className="h-4 w-4 inline mr-2" />
              {language === 'AR' ? 'English' : 'عربي'}
            </button>
          </div>
        </div>
      )}
      
      {/* Login Modal */}
      <LoginModal isOpen={showLoginModal} onClose={() => setShowLoginModal(false)} />
    </nav>
  );
};

export default Navbar;